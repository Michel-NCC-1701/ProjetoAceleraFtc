﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ehoprojetinnepae
{
    public partial class Pong : Form
    {
        private int paddleWidth = 20;
        private int paddleHeight = 100;
        private int ballSize = 20;

        private int leftPaddleY, rightPaddleY, ballX, ballY;
        private int ballSpeedX, ballSpeedY;
        private int paddleSpeed = 10;

        private Timer gameTimer;
        private object components;

        public Pong()
        {
            InitializeComponent();
            this.Text = "Pong Game";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.ClientSize = new Size(800, 600);
            this.DoubleBuffered = true;

            // Inicialização das variáveis do jogo
            leftPaddleY = rightPaddleY = (this.ClientSize.Height - paddleHeight) / 2;
            ballX = this.ClientSize.Width / 2 - ballSize / 2;
            ballY = this.ClientSize.Height / 2 - ballSize / 2;
            ballSpeedX = 4;
            ballSpeedY = 4;

            // Configuração do Timer
            gameTimer = new Timer();
            gameTimer.Interval = 16; // Aproximadamente 60 FPS
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            // Eventos de teclado
            this.KeyDown += Form1_KeyDown;
            this.KeyUp += Form1_KeyUp;
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            // Movendo a bola
            ballX += ballSpeedX;
            ballY += ballSpeedY;

            // Colisão superior e inferior
            if (ballY <= 0 || ballY + ballSize >= this.ClientSize.Height)
            {
                ballSpeedY = -ballSpeedY;
            }

            // Colisão com as paletas
            if (ballX <= paddleWidth && ballY + ballSize >= leftPaddleY && ballY <= leftPaddleY + paddleHeight)
            {
                ballSpeedX = -ballSpeedX;
            }

            if (ballX + ballSize >= this.ClientSize.Width - paddleWidth && ballY + ballSize >= rightPaddleY && ballY <= rightPaddleY + paddleHeight)
            {
                ballSpeedX = -ballSpeedX;
            }

            // Pontuação e reposicionamento da bola
            if (ballX < 0 || ballX + ballSize > this.ClientSize.Width)
            {
                ballX = this.ClientSize.Width / 2 - ballSize / 2;
                ballY = this.ClientSize.Height / 2 - ballSize / 2;
                ballSpeedX = -ballSpeedX;
            }

            // Atualizando a tela
            this.Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W && leftPaddleY > 0)
            {
                leftPaddleY -= paddleSpeed; // Movendo a paleta esquerda para cima
            }
            if (e.KeyCode == Keys.S && leftPaddleY < this.ClientSize.Height - paddleHeight)
            {
                leftPaddleY += paddleSpeed; // Movendo a paleta esquerda para baixo
            }
            if (e.KeyCode == Keys.Up && rightPaddleY > 0)
            {
                rightPaddleY -= paddleSpeed; // Movendo a paleta direita para cima
            }
            if (e.KeyCode == Keys.Down && rightPaddleY < this.ClientSize.Height - paddleHeight)
            {
                rightPaddleY += paddleSpeed; // Movendo a paleta direita para baixo
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            // Se necessário, podemos adicionar lógica para parar as paletas quando as teclas forem soltas
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;

            // Desenhando as paletas
            g.FillRectangle(Brushes.MediumPurple, 0, leftPaddleY, paddleWidth, paddleHeight); // Paleta esquerda
            g.FillRectangle(Brushes.Indigo, this.ClientSize.Width - paddleWidth, rightPaddleY, paddleWidth, paddleHeight); // Paleta direita

            // Desenhando a bola
            g.FillEllipse(Brushes.Green, ballX, ballY, ballSize, ballSize);

            // Desenhando a linha central
            g.DrawLine(Pens.White, this.ClientSize.Width / 2, 0, this.ClientSize.Width / 2, this.ClientSize.Height);
        }

        // Código do Dispose gerado automaticamente
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Name = "Form1";
            this.Text = "Pong Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Event handler de carregamento do formulário
        }

        #endregion
    }
}

