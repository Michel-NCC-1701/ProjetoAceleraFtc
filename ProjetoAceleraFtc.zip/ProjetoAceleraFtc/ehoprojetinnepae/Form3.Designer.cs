﻿namespace ehoprojetinnepae
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.postButton = new System.Windows.Forms.Button();
            this.feedPanel = new System.Windows.Forms.Panel();
            this.panelAdd = new System.Windows.Forms.Panel();
            this.addMidImg = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sairButton = new System.Windows.Forms.Button();
            this.panelPessoas = new System.Windows.Forms.Panel();
            this.msgSolidao = new System.Windows.Forms.Label();
            this.pessoasLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Amigos = new System.Windows.Forms.Label();
            this.pingouNotificacao = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.jogarButton = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonNotificacao = new System.Windows.Forms.PictureBox();
            this.imagemPerfil = new System.Windows.Forms.PictureBox();
            this.buscaBox = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.feedPanel.SuspendLayout();
            this.panelAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.addMidImg)).BeginInit();
            this.panelPessoas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buttonNotificacao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagemPerfil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(0)))), ((int)(((byte)(70)))));
            this.panel2.Location = new System.Drawing.Point(97, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 684);
            this.panel2.TabIndex = 1;
            // 
            // postButton
            // 
            this.postButton.BackColor = System.Drawing.Color.White;
            this.postButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postButton.Location = new System.Drawing.Point(25, 410);
            this.postButton.Name = "postButton";
            this.postButton.Size = new System.Drawing.Size(50, 50);
            this.postButton.TabIndex = 2;
            this.postButton.Text = "+";
            this.postButton.UseVisualStyleBackColor = false;
            this.postButton.Click += new System.EventHandler(this.postButton_Click);
            // 
            // feedPanel
            // 
            this.feedPanel.AutoScroll = true;
            this.feedPanel.BackColor = System.Drawing.Color.White;
            this.feedPanel.Controls.Add(this.panelAdd);
            this.feedPanel.Location = new System.Drawing.Point(108, 46);
            this.feedPanel.Name = "feedPanel";
            this.feedPanel.Size = new System.Drawing.Size(936, 634);
            this.feedPanel.TabIndex = 4;
            // 
            // panelAdd
            // 
            this.panelAdd.Controls.Add(this.addMidImg);
            this.panelAdd.Controls.Add(this.label1);
            this.panelAdd.Location = new System.Drawing.Point(432, 250);
            this.panelAdd.Name = "panelAdd";
            this.panelAdd.Size = new System.Drawing.Size(113, 219);
            this.panelAdd.TabIndex = 8;
            // 
            // addMidImg
            // 
            this.addMidImg.BackgroundImage = global::ehoprojetinnepae.Properties.Resources._3521088_200;
            this.addMidImg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addMidImg.Location = new System.Drawing.Point(0, 0);
            this.addMidImg.Name = "addMidImg";
            this.addMidImg.Size = new System.Drawing.Size(113, 113);
            this.addMidImg.TabIndex = 6;
            this.addMidImg.TabStop = false;
            this.addMidImg.Click += new System.EventHandler(this.addMidImg_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 106);
            this.label1.TabIndex = 7;
            this.label1.Text = "Ainda não tem nenhuma postagem, seja o primeiro a postar!";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(0)))), ((int)(((byte)(70)))));
            this.panel1.Location = new System.Drawing.Point(1045, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 684);
            this.panel1.TabIndex = 5;
            // 
            // sairButton
            // 
            this.sairButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sairButton.ForeColor = System.Drawing.Color.Black;
            this.sairButton.Location = new System.Drawing.Point(25, 610);
            this.sairButton.Name = "sairButton";
            this.sairButton.Size = new System.Drawing.Size(50, 50);
            this.sairButton.TabIndex = 6;
            this.sairButton.Text = "X";
            this.sairButton.UseVisualStyleBackColor = true;
            this.sairButton.Click += new System.EventHandler(this.sairButton_Click);
            // 
            // panelPessoas
            // 
            this.panelPessoas.AutoScroll = true;
            this.panelPessoas.Controls.Add(this.msgSolidao);
            this.panelPessoas.Controls.Add(this.pessoasLabel);
            this.panelPessoas.Location = new System.Drawing.Point(1055, 0);
            this.panelPessoas.Name = "panelPessoas";
            this.panelPessoas.Size = new System.Drawing.Size(209, 684);
            this.panelPessoas.TabIndex = 7;
            // 
            // msgSolidao
            // 
            this.msgSolidao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msgSolidao.Location = new System.Drawing.Point(29, 145);
            this.msgSolidao.Name = "msgSolidao";
            this.msgSolidao.Size = new System.Drawing.Size(158, 60);
            this.msgSolidao.TabIndex = 1;
            this.msgSolidao.Text = "Você foi o primeiro a chegar convide seus amigos!";
            this.msgSolidao.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pessoasLabel
            // 
            this.pessoasLabel.AutoSize = true;
            this.pessoasLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pessoasLabel.Location = new System.Drawing.Point(3, 9);
            this.pessoasLabel.Name = "pessoasLabel";
            this.pessoasLabel.Size = new System.Drawing.Size(106, 29);
            this.pessoasLabel.TabIndex = 0;
            this.pessoasLabel.Text = "Pessoas";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Perfil";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 460);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Postar";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 660);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Sair";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 380);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Notificação";
            // 
            // Amigos
            // 
            this.Amigos.AutoSize = true;
            this.Amigos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Amigos.Location = new System.Drawing.Point(19, 220);
            this.Amigos.Name = "Amigos";
            this.Amigos.Size = new System.Drawing.Size(62, 20);
            this.Amigos.TabIndex = 14;
            this.Amigos.Text = "Amigos";
            this.Amigos.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pingouNotificacao
            // 
            this.pingouNotificacao.BackColor = System.Drawing.Color.Red;
            this.pingouNotificacao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pingouNotificacao.Location = new System.Drawing.Point(57, 335);
            this.pingouNotificacao.Name = "pingouNotificacao";
            this.pingouNotificacao.Size = new System.Drawing.Size(15, 15);
            this.pingouNotificacao.TabIndex = 15;
            this.pingouNotificacao.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(-2, 300);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Comunidade";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 25);
            this.label7.TabIndex = 19;
            this.label7.Text = "Inicio";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 540);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "Jogar";
            // 
            // jogarButton
            // 
            this.jogarButton.BackColor = System.Drawing.Color.White;
            this.jogarButton.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.controle_de_video_game;
            this.jogarButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jogarButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jogarButton.Location = new System.Drawing.Point(25, 490);
            this.jogarButton.Name = "jogarButton";
            this.jogarButton.Size = new System.Drawing.Size(50, 50);
            this.jogarButton.TabIndex = 20;
            this.jogarButton.UseVisualStyleBackColor = false;
            this.jogarButton.Click += new System.EventHandler(this.jogarButton_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.logoImg;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(25, 10);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.multidao_de_usuarios;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(25, 250);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.amigos;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(25, 170);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // buttonNotificacao
            // 
            this.buttonNotificacao.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.notificacao;
            this.buttonNotificacao.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonNotificacao.Location = new System.Drawing.Point(25, 330);
            this.buttonNotificacao.Name = "buttonNotificacao";
            this.buttonNotificacao.Size = new System.Drawing.Size(50, 50);
            this.buttonNotificacao.TabIndex = 11;
            this.buttonNotificacao.TabStop = false;
            this.buttonNotificacao.Click += new System.EventHandler(this.buttonNotificacao_Click);
            // 
            // imagemPerfil
            // 
            this.imagemPerfil.BackgroundImage = global::ehoprojetinnepae.Properties.Resources._74472;
            this.imagemPerfil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imagemPerfil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imagemPerfil.Location = new System.Drawing.Point(25, 90);
            this.imagemPerfil.Name = "imagemPerfil";
            this.imagemPerfil.Size = new System.Drawing.Size(50, 50);
            this.imagemPerfil.TabIndex = 3;
            this.imagemPerfil.TabStop = false;
            this.imagemPerfil.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // buscaBox
            // 
            this.buscaBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.buscaBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buscaBox.Location = new System.Drawing.Point(328, 10);
            this.buscaBox.Name = "buscaBox";
            this.buscaBox.Size = new System.Drawing.Size(500, 29);
            this.buscaBox.TabIndex = 22;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.procurar;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(834, 10);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(30, 30);
            this.pictureBox4.TabIndex = 23;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.buscaBox);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.jogarButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pingouNotificacao);
            this.Controls.Add(this.Amigos);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.buttonNotificacao);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panelPessoas);
            this.Controls.Add(this.sairButton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.imagemPerfil);
            this.Controls.Add(this.postButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.feedPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Feed";
            this.feedPanel.ResumeLayout(false);
            this.panelAdd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.addMidImg)).EndInit();
            this.panelPessoas.ResumeLayout(false);
            this.panelPessoas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buttonNotificacao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagemPerfil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button postButton;
        private System.Windows.Forms.PictureBox imagemPerfil;
        private System.Windows.Forms.Panel feedPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button sairButton;
        private System.Windows.Forms.Panel panelPessoas;
        private System.Windows.Forms.Label pessoasLabel;
        private System.Windows.Forms.Label msgSolidao;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox buttonNotificacao;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Amigos;
        private System.Windows.Forms.Panel pingouNotificacao;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox addMidImg;
        private System.Windows.Forms.Button jogarButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox buscaBox;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}