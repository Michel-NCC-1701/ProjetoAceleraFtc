﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ehoprojetinnepae
{

    public partial class Cobrinha : Form
    {

        private List<Rectangle> snake;  // Lista para armazenar os segmentos da cobra
        private Rectangle food;         // Posição da comida
        private int gridSize = 20;      // Tamanho de cada "bloco" do grid
        private int width = 30;         // Quantidade de blocos na largura do jogo
        private int height = 20;        // Quantidade de blocos na altura
        private int score;              // Pontuação
        private string direction = "RIGHT"; // Direção inicial da cobra
        private Timer gameTimer;        // Timer para o movimento
        private Random rand;            // Gerador de números aleatórios para comida

        public Cobrinha()
        {
            InitializeComponent();

            // Configurações do jogo
            this.Width = width * gridSize + 16;  // Largura do form
            this.Height = height * gridSize + 39; // Altura do form
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Text = "Jogo da Cobrinha";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.DoubleBuffered = true; // Melhorar a performance desenhando no painel de forma eficiente

            rand = new Random();
            snake = new List<Rectangle>();
            score = 0;

            // Inicializando a cobra no meio da tela
            snake.Add(new Rectangle(100, 100, gridSize, gridSize));

            // Criar comida
            GenerateFood();

            // Criar Timer para o movimento
            gameTimer = new Timer();
            gameTimer.Interval = 100; // A cada 100ms
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            // Capturar as teclas pressionadas
            this.KeyDown += Form1_KeyDown;
        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up && direction != "DOWN")
                direction = "UP";
            else if (e.KeyCode == Keys.Down && direction != "UP")
                direction = "DOWN";
            else if (e.KeyCode == Keys.Left && direction != "RIGHT")
                direction = "LEFT";
            else if (e.KeyCode == Keys.Right && direction != "LEFT")
                direction = "RIGHT";
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            // Atualizar a posição da cobra
            MoveSnake();
            CheckCollisions();
            CheckFoodCollision();

            // Redesenhar o jogo
            this.Invalidate();
        }

        private void MoveSnake()
        {
            // Obter a posição atual da cabeça da cobra
            Rectangle head = snake.First();

            switch (direction)
            {
                case "UP":
                    head.Y -= gridSize;
                    break;
                case "DOWN":
                    head.Y += gridSize;
                    break;
                case "LEFT":
                    head.X -= gridSize;
                    break;
                case "RIGHT":
                    head.X += gridSize;
                    break;
            }

            // Adicionar nova posição da cabeça
            snake.Insert(0, head);

            // Se a cobra não pegou comida, remover a cauda
            if (head.Equals(food))
            {
                score += 10;
                GenerateFood();
            }
            else
            {
                snake.RemoveAt(snake.Count - 1);
            }
        }

        private void CheckCollisions()
        {
            Rectangle head = snake.First();

            // Colisão com a parede
            if (head.X < 0 || head.X >= width * gridSize || head.Y < 0 || head.Y >= height * gridSize)
            {
                EndGame();
            }

            // Colisão com o próprio corpo
            for (int i = 1; i < snake.Count; i++)
            {
                if (head.Equals(snake[i]))
                {
                    EndGame();
                }
            }
        }

        private void CheckFoodCollision()
        {
            Rectangle head = snake.First();

            // Verifica se a cobra comeu a comida
            if (head.Equals(food))
            {
                score += 10;
                GenerateFood();
            }
        }

        private void GenerateFood()
        {
            // Gerar uma nova posição para a comida
            int foodX = rand.Next(0, width) * gridSize;
            int foodY = rand.Next(0, height) * gridSize;
            food = new Rectangle(foodX, foodY, gridSize, gridSize);
        }

        private void EndGame()
        {
            // Exibir a pontuação final e parar o jogo
            gameTimer.Stop();
            MessageBox.Show($"Game Over! Sua pontuação foi {score}", "Fim de Jogo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Desenhar a cobra
            foreach (var segment in snake)
            {
                e.Graphics.FillRectangle(Brushes.MediumPurple, segment);
            }

            // Desenhar a comida
            e.Graphics.FillRectangle(Brushes.Red, food);

            // Exibir a pontuação
            e.Graphics.DrawString($"Score: {score}", new Font("Arial", 12), Brushes.Black, new Point(10, 10));
        }
    }
}


