﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Comunidades;


namespace ehoprojetinnepae
{
    public partial class Form7 : Form
    {
        private List<Conversas> listaConversas = new List<Conversas>();
        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Comunidade> listaComunidades = new List<Comunidade>();
        List<Postagem> listaPostagem = new List<Postagem>();

        Form7 amigos;

        Panel linhaLateral = new Panel();
        Button buttonAdd = new Button();
        Button buttonSair = new Button();

        PictureBox buttonAmg = new PictureBox();
        PictureBox buttonCmnd = new PictureBox();
        PictureBox buttonNtf = new PictureBox();
        PictureBox homeImg = new PictureBox();

        int contU;
        bool menu = false;
        public Form7(List<Usuario> listaUsuario, int contU, List<Postagem> listaPostagem, List<Conversas> listaConversa, List<Comunidade> listaComunidades)
        {
            amigos = this;
            this.listaComunidades = listaComunidades;
            listaConversas = listaConversa;
            this.listaUsuario = listaUsuario;
            this.listaPostagem = listaPostagem;
            this.contU = contU;

            InitializeComponent();

            criarAmigos();

            buttonSair.Click += new EventHandler(buttonSair_Click);
            buttonAdd.Click += new EventHandler(buttonAdd_Click);
            homeImg.Click += new EventHandler(homeImg_Click);
            buttonCmnd.Click += new EventHandler(buttonCmnd_Click);
        }

        public class Conversas
        {
            public int idConversa { get; set; }
            public List<Mensagem> listaMensagens { get; set; } = new List<Mensagem>();
            public List<Pessoas> listaPessoas { get; set; } = new List<Pessoas>();
        }

        public class Pessoas
        {
            public int idPessoa { get; set; }
        }

        public class Mensagem
        {
            public String mensagemTxt { get; set; }
            public int idRemetente { get; set;}
        }

        private void buttonCmnd_Click(object sender, EventArgs e)
        {
            Comunidades comunidades = new Comunidades(listaUsuario, contU, listaPostagem, listaConversas, listaComunidades);
            comunidades.Show();
            this.Close();
        }

        private void homeImg_Click(object sender, EventArgs e)
        {
            Form3 feed = new Form3(listaUsuario, contU, listaPostagem, listaConversas, listaComunidades);
            feed.Show();
            this.Close();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Form5 postagemUsuario = new Form5(listaUsuario, contU, listaPostagem, amigos, listaConversas, listaComunidades);
            postagemUsuario.Show();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            Form2 login = new Form2(null, listaUsuario, listaPostagem, listaConversas, listaComunidades);
            login.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (menu == false)
            {
                criarPanel();
                menu = true;
                button1.BringToFront();

                if (linhaLateral.Visible == false)
                {
                    linhaLateral.Visible = true;
                }
            }
            else if (menu == true)
            {
                linhaLateral.Visible = false;
                menu = false;
            }
        }

        public void criarAmigos()
        {
            if (listaUsuario[contU].listaAmigos != null && listaUsuario[contU].listaAmigos.Count > 0)
            {
                int locPerf = 55;

                msgSolidao.Visible = false;
                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    if (listaUsuario[contU].listaAmigos[i].amizade == true)
                    {
                        Panel panelAmigo = new Panel
                        {
                            Location = new Point(0, locPerf),
                            Size = new Size(553, 90),
                            BackColor = Color.White
                        };
                        amigos.Controls.Add(panelAmigo);
                        panelAmigo.Click += new EventHandler(panelAmigo_Click);

                        PictureBox imgAmg = new PictureBox
                        {
                            Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo,
                            Location = new Point(10, 10),
                            Size = new Size(60, 60),
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            BorderStyle = BorderStyle.FixedSingle
                        };

                        if (listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem != null)
                        {
                            imgAmg.Image = Image.FromFile(listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem.FileName);
                        }
                        else
                        {
                            imgAmg.Image = Image.FromFile("Resources\\74472.png");
                        }

                        imgAmg.Click += new EventHandler(panelAmigo_Click);
                        panelAmigo.Controls.Add(imgAmg);

                        Label nomeAmg = new Label
                        {
                            Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo,
                            Location = new Point(73, 10),
                            Size = new Size(477, 60),
                            Font = new Font("Microsoft Sans Serif", 16),
                            Text = listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Nome
                        };
                        nomeAmg.Click += new EventHandler(panelAmigo_Click);
                        panelAmigo.Controls.Add(nomeAmg);
                        panelAmigo.Name = "" + i;

                        locPerf += 100;
                    }
                }
            }
        }

        public void panelAmigo_Click(object sender, EventArgs e)
        {
            Control clickedControl = sender as Control;
            Panel panelAmigo = clickedControl.Parent as Panel;

            if (panelAmigo == null)
            {
                return;
            }

            int posAmg;
            if (!int.TryParse(panelAmigo.Name, out posAmg))
            {
                return;
            }

            if (posAmg < 0 || posAmg >= listaUsuario[contU].listaAmigos.Count)
            {
                return;
            }

            boxMsg.Visible = true;
            buttonMsg.Visible = true;
            buttonMsg.Name = "" + listaUsuario[contU].listaAmigos[posAmg].idAmigo; // Use o ID do amigo
            panelNome.Visible = true;
            labelMsg.Text = listaUsuario[listaUsuario[contU].listaAmigos[posAmg].idAmigo].Nome;

            if (listaUsuario[listaUsuario[contU].listaAmigos[posAmg].idAmigo].Imagem != null)
            {
                pictureMsg.Image = Image.FromFile(listaUsuario[listaUsuario[contU].listaAmigos[posAmg].idAmigo].Imagem.FileName);
                pictureMsg.SizeMode = PictureBoxSizeMode.StretchImage;
            }

            // Verifica se a lista de conversas está inicializada
            if (listaConversas == null)
            {
                listaConversas = new List<Conversas>();
            }

            // Verifica se a conversa já existe
            int amigoId = listaUsuario[contU].listaAmigos[posAmg].idAmigo;
            Conversas conversaExistente = listaConversas.Find(c => c.listaPessoas != null && c.listaPessoas.Exists(p => p.idPessoa == amigoId));

            if (conversaExistente != null)
            {
                // Se a conversa já existir, exibe as mensagens
                exibirMsg(listaConversas.IndexOf(conversaExistente));
            }
            else
            {
                // Se não existir, exibe uma conversa vazia
                LimparMensagens();
            }
        }

        public void exibirMsg(int posConversa)
        {
            LimparMensagens();
            for (int i = 0; i < listaConversas[posConversa].listaMensagens.Count; i++)
            {
                Label msg = new Label
                {
                    Size = new Size(600, 50),
                    AutoSize = false,
                    Text = listaConversas[posConversa].listaMensagens[i].mensagemTxt,
                    Font = new Font("Microsoft Sans Serif", 12),
                    RightToLeft = (listaConversas[posConversa].listaMensagens[i].idRemetente == contU) ? RightToLeft.Yes : RightToLeft.No
                };

                flowLayoutPanel1.Controls.Add(msg);
            }
        }

        public void criarPanel()
        {
            Panel linhaDesign = new Panel();

            Label logo = new Label
            {
                Location = new Point(25, 140),
                Text = "Inicio",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label perfil = new Label
            {
                Location = new Point(25, 220),
                Text = "Perfil",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label amigos = new Label
            {
                Location = new Point(19, 300),
                Text = "Amigos",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label Comunidade = new Label
            {
                Location = new Point(-2, 380),
                Text = "Comunidades",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label notificacao = new Label
            {
                Location = new Point(9, 460),
                Text = "Notificação",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label postarMais = new Label
            {
                Location = new Point(23, 540),
                Text = "Postar",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label sair = new Label
            {
                Location = new Point(28, 660),
                Text = "Sair",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            PictureBox perfilImg = new PictureBox();

            linhaLateral.Location = new Point(0, 0);
            linhaLateral.Size = new Size(110, 684);
            linhaLateral.BackColor = Color.White;

            linhaDesign.Location = new Point(100, 0);
            linhaDesign.Size = new Size(10, 684);
            linhaDesign.BackColor = Color.FromArgb(70, 0, 70);

            homeImg.Location = new Point(25, 90);
            homeImg.Size = new Size(50, 50);
            homeImg.SizeMode = PictureBoxSizeMode.Zoom;
            homeImg.BorderStyle = BorderStyle.FixedSingle;
            homeImg.Image = Image.FromFile("Resources\\logoImg.png");

            if (listaUsuario[contU].Imagem == null)
            {
                perfilImg.Location = new Point(25, 170);
                perfilImg.Size = new Size(50, 50);
                perfilImg.BorderStyle = BorderStyle.FixedSingle;
                perfilImg.SizeMode = PictureBoxSizeMode.StretchImage;
                perfilImg.Image = Image.FromFile("Resources\\74472.png");
            }
            else
            {
                perfilImg.Location = new Point(25, 170);
                perfilImg.Size = new Size(50, 50);
                perfilImg.BackgroundImage = null;
                perfilImg.BorderStyle = BorderStyle.FixedSingle;
                perfilImg.SizeMode = PictureBoxSizeMode.StretchImage;
                perfilImg.Image = Image.FromFile(listaUsuario[contU].Imagem.FileName);
            }

            buttonAmg.Location = new Point(25, 250);
            buttonAmg.Size = new Size(50, 50);
            buttonAmg.SizeMode = PictureBoxSizeMode.Zoom;
            buttonAmg.BorderStyle = BorderStyle.FixedSingle;
            buttonAmg.Image = Image.FromFile("Resources\\amigos.png");

            buttonCmnd.Location = new Point(25, 330);
            buttonCmnd.Size = new Size(50, 50);
            buttonCmnd.SizeMode = PictureBoxSizeMode.Zoom;
            buttonCmnd.BorderStyle = BorderStyle.FixedSingle;
            buttonCmnd.Image = Image.FromFile("Resources\\multidao-de-usuarios.png");

            buttonNtf.Location = new Point(25, 410);
            buttonNtf.Size = new Size(50, 50);
            buttonNtf.SizeMode = PictureBoxSizeMode.Zoom;
            buttonNtf.BorderStyle = BorderStyle.FixedSingle;
            buttonNtf.Image = Image.FromFile("Resources\\notificacao.png");

            buttonAdd.Location = new Point(25, 490);
            buttonAdd.Size = new Size(50, 50);
            buttonAdd.BackColor = Color.White;
            buttonAdd.Text = "+";
            buttonAdd.TextAlign = ContentAlignment.MiddleCenter;
            buttonAdd.ImageAlign = ContentAlignment.MiddleCenter;
            buttonAdd.Font = new Font("Microsoft Sans Serif", 16);

            buttonSair.Location = new Point(25, 610);
            buttonSair.Size = new Size(50, 50);
            buttonSair.BackColor = Color.White;
            buttonSair.Text = "X";
            buttonSair.TextAlign = ContentAlignment.MiddleCenter;
            buttonSair.ImageAlign = ContentAlignment.MiddleCenter;
            buttonSair.Font = new Font("Microsoft Sans Serif", 16);

            this.Controls.Add(linhaLateral);
            linhaLateral.Controls.Add(linhaDesign);
            linhaLateral.Controls.Add(homeImg);
            linhaLateral.Controls.Add(perfilImg);
            linhaLateral.Controls.Add(buttonAmg);
            linhaLateral.Controls.Add(buttonCmnd);
            linhaLateral.Controls.Add(buttonNtf);
            linhaLateral.Controls.Add(buttonAdd);
            linhaLateral.Controls.Add(buttonSair);
            linhaLateral.Controls.Add(logo);
            linhaLateral.Controls.Add(amigos);
            linhaLateral.Controls.Add(Comunidade);
            linhaLateral.Controls.Add(notificacao);
            linhaLateral.Controls.Add(postarMais);
            linhaLateral.Controls.Add(perfil);
            linhaLateral.Controls.Add(sair);
            linhaLateral.BringToFront();
        }

        private void LimparMensagens()
        {
            flowLayoutPanel1.Controls.Clear(); 
        }

        private void buttonMsg_Click(object sender, EventArgs e)
        {
            // Verifica se o botão de mensagem foi clicado
            if (sender is Button button)
            {
                int pessoa2;
                // Tenta converter o nome do botão para um inteiro
                if (!int.TryParse(button.Name, out pessoa2))
                {
                    MessageBox.Show("Erro ao identificar a pessoa para a conversa.");
                    return;
                }

                // Verifica se a lista de conversas é nula ou vazia
                if (listaConversas == null)
                {
                    listaConversas = new List<Conversas>();
                }

                // Verifica se a conversa já existe
                Conversas conversaExistente = listaConversas.Find(c => c.listaPessoas.Exists(p => p.idPessoa == pessoa2));

                if (conversaExistente == null)
                {
                    // Se não existir, cria uma nova conversa
                    Conversas novaConversa = new Conversas
                    {
                        idConversa = listaConversas.Count + 1,
                        listaPessoas = new List<Pessoas>
                {
                    new Pessoas { idPessoa = contU },
                    new Pessoas { idPessoa = pessoa2 }
                }
                    };
                    listaConversas.Add(novaConversa);
                    exibirMsg(listaConversas.Count - 1); // Exibe a nova conversa
                }
                else
                {
                    // Se a conversa já existir, exibe as mensagens
                    exibirMsg(listaConversas.IndexOf(conversaExistente));
                }

                // Verifica se a caixa de mensagem não está vazia
                if (!string.IsNullOrWhiteSpace(boxMsg.Text))
                {
                    Mensagem mensagem = new Mensagem
                    {
                        mensagemTxt = boxMsg.Text,
                        idRemetente = contU
                    };

                    // Adiciona a mensagem à conversa correta
                    if (conversaExistente != null)
                    {
                        listaConversas[listaConversas.IndexOf(conversaExistente)].listaMensagens.Add(mensagem);
                        exibirMsg(listaConversas.IndexOf(conversaExistente)); // Atualiza a exibição imediatamente
                    }
                    else
                    {
                        // Se a conversa foi recém-criada, adiciona a mensagem à nova conversa
                        listaConversas[listaConversas.Count - 1].listaMensagens.Add(mensagem);
                        exibirMsg(listaConversas.Count - 1); // Exibe a nova conversa
                    }

                    // Limpa a caixa de mensagem
                    boxMsg.Clear();
                }
                else
                {
                    MessageBox.Show("A mensagem não pode estar vazia.");
                }
            }
        }

        public void criarMsgs(int idConversa)
        {
            Mensagem mensagem = new Mensagem()
            {
                mensagemTxt = boxMsg.Text,
                idRemetente = contU
            };

            listaConversas[idConversa].listaMensagens.Add(mensagem);
            exibirMsg(idConversa);
        }
    }
    }