﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;

namespace ehoprojetinnepae
{
    public partial class Form9 : Form
    {
        int contU;

        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Conversas> listaConversa = new List<Conversas>();
        private List<Comunidades.Comunidade> listaComunidades = new List<Comunidades.Comunidade>();
        private List<Postagem> listaPostagem = new List<Postagem>();

        public Form9(List<Usuario> listaUsuario, int contU, List<Postagem> listaPostagem, List<Conversas> listaConversa, List<Comunidades.Comunidade> listacomunidade)
        {
            listaComunidades = listacomunidade;
            this.listaUsuario = listaUsuario;
            this.listaConversa = listaConversa;
            this.contU = contU;

            InitializeComponent();

            if (listaPostagem != null)
            {
                this.listaPostagem = listaPostagem;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Cobrinha jogoCobra = new Cobrinha();
            jogoCobra.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 feed = new Form3(listaUsuario, contU, listaPostagem, listaConversa, listaComunidades);
            feed.Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Pong pong = new Pong();
            pong.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Flappy flappy = new Flappy();
            flappy.Show();
        }
    }
}
