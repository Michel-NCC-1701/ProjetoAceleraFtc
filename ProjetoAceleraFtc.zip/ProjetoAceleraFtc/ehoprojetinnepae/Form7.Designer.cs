﻿namespace ehoprojetinnepae
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.msgSolidao = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.boxMsg = new System.Windows.Forms.TextBox();
            this.buttonMsg = new System.Windows.Forms.Button();
            this.panelNome = new System.Windows.Forms.Panel();
            this.msgs = new System.Windows.Forms.Panel();
            this.labelMsg = new System.Windows.Forms.Label();
            this.pictureMsg = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelMsg = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panelNome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMsg)).BeginInit();
            this.panelMsg.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(0)))), ((int)(((byte)(70)))));
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Location = new System.Drawing.Point(630, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 684);
            this.panel2.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(0)))), ((int)(((byte)(70)))));
            this.panel1.Location = new System.Drawing.Point(13, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 684);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 29);
            this.label1.TabIndex = 8;
            this.label1.Text = "Amigos";
            // 
            // msgSolidao
            // 
            this.msgSolidao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msgSolidao.Location = new System.Drawing.Point(193, 253);
            this.msgSolidao.Name = "msgSolidao";
            this.msgSolidao.Size = new System.Drawing.Size(170, 83);
            this.msgSolidao.TabIndex = 9;
            this.msgSolidao.Text = "Você ainda não tem nenhum amigo.";
            this.msgSolidao.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::ehoprojetinnepae.Properties.Resources._17701;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(25, 10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 7;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // boxMsg
            // 
            this.boxMsg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.boxMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boxMsg.Location = new System.Drawing.Point(6, 632);
            this.boxMsg.Multiline = true;
            this.boxMsg.Name = "boxMsg";
            this.boxMsg.Size = new System.Drawing.Size(560, 35);
            this.boxMsg.TabIndex = 0;
            this.boxMsg.Visible = false;
            // 
            // buttonMsg
            // 
            this.buttonMsg.BackColor = System.Drawing.Color.Transparent;
            this.buttonMsg.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.next;
            this.buttonMsg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonMsg.Location = new System.Drawing.Point(572, 629);
            this.buttonMsg.Name = "buttonMsg";
            this.buttonMsg.Size = new System.Drawing.Size(40, 40);
            this.buttonMsg.TabIndex = 1;
            this.buttonMsg.UseVisualStyleBackColor = false;
            this.buttonMsg.Visible = false;
            this.buttonMsg.Click += new System.EventHandler(this.buttonMsg_Click);
            // 
            // panelNome
            // 
            this.panelNome.BackColor = System.Drawing.Color.MediumPurple;
            this.panelNome.Controls.Add(this.msgs);
            this.panelNome.Controls.Add(this.labelMsg);
            this.panelNome.Controls.Add(this.pictureMsg);
            this.panelNome.Location = new System.Drawing.Point(0, 0);
            this.panelNome.Name = "panelNome";
            this.panelNome.Size = new System.Drawing.Size(616, 61);
            this.panelNome.TabIndex = 2;
            this.panelNome.Visible = false;
            // 
            // msgs
            // 
            this.msgs.BackColor = System.Drawing.Color.White;
            this.msgs.Location = new System.Drawing.Point(0, 61);
            this.msgs.Name = "msgs";
            this.msgs.Size = new System.Drawing.Size(660, 562);
            this.msgs.TabIndex = 3;
            // 
            // labelMsg
            // 
            this.labelMsg.AutoSize = true;
            this.labelMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMsg.Location = new System.Drawing.Point(57, 28);
            this.labelMsg.Name = "labelMsg";
            this.labelMsg.Size = new System.Drawing.Size(60, 24);
            this.labelMsg.TabIndex = 1;
            this.labelMsg.Text = "label2";
            // 
            // pictureMsg
            // 
            this.pictureMsg.BackColor = System.Drawing.Color.White;
            this.pictureMsg.BackgroundImage = global::ehoprojetinnepae.Properties.Resources._74472;
            this.pictureMsg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureMsg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureMsg.Location = new System.Drawing.Point(6, 7);
            this.pictureMsg.Name = "pictureMsg";
            this.pictureMsg.Size = new System.Drawing.Size(45, 45);
            this.pictureMsg.TabIndex = 0;
            this.pictureMsg.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 61);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(609, 559);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // panelMsg
            // 
            this.panelMsg.AutoScroll = true;
            this.panelMsg.Controls.Add(this.panelNome);
            this.panelMsg.Controls.Add(this.buttonMsg);
            this.panelMsg.Controls.Add(this.boxMsg);
            this.panelMsg.Controls.Add(this.flowLayoutPanel1);
            this.panelMsg.Location = new System.Drawing.Point(640, 2);
            this.panelMsg.Name = "panelMsg";
            this.panelMsg.Size = new System.Drawing.Size(619, 678);
            this.panelMsg.TabIndex = 10;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelMsg);
            this.Controls.Add(this.msgSolidao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Amigos";
            this.panel2.ResumeLayout(false);
            this.panelNome.ResumeLayout(false);
            this.panelNome.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMsg)).EndInit();
            this.panelMsg.ResumeLayout(false);
            this.panelMsg.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label msgSolidao;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox boxMsg;
        private System.Windows.Forms.Button buttonMsg;
        private System.Windows.Forms.Panel panelNome;
        private System.Windows.Forms.Panel msgs;
        private System.Windows.Forms.Label labelMsg;
        private System.Windows.Forms.PictureBox pictureMsg;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panelMsg;
    }
}