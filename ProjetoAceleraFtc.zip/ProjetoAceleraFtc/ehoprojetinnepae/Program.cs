﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ehoprojetinnepae
{
    internal static class Program
    {
        private static List<Form1.Usuario> listaUsuario;
        private static List<Form5.Postagem> listaPostagem;
        private static List<Form7.Conversas> listaConversas;
        private static List<Comunidades.Comunidade> listaComunidade; 

        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(listaUsuario, listaPostagem, listaConversas, listaComunidade));
        }
    }
}
