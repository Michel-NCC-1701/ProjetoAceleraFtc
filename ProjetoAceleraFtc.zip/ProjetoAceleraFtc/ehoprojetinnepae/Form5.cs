﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static ehoprojetinnepae.Comunidades;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form7;

namespace ehoprojetinnepae
{
    public partial class Form5 : Form
    {
        Postagem postagem = new Postagem();
        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Postagem> listaPostagem = new List<Postagem>();
        private List<Conversas> listaConversa = new List<Conversas>();
        private List<Comunidade> listaComunidade = new List<Comunidade>();

        Form formController = new Form();
       
        int contU, idCmnd = -1;

        Label nomeCmnd = new Label();
        private OpenFileDialog imagemPost = new OpenFileDialog();

        public Form5(List<Usuario> listaUsuario, int contU, List<Postagem> listaPostagem, Form formController, List<Conversas> listaConversa, List<Comunidade> listaComunidades)
        {
            this.formController = formController;
            if (listaComunidades != null)
            {
                listaComunidade = listaComunidades;
            }
            this.listaUsuario = listaUsuario;
            this.listaConversa = listaConversa;
            this.listaPostagem = listaPostagem;
            this.contU = contU;
            InitializeComponent();

            postNameLabel.Visible = true;
            postNameLabel.Text = listaUsuario[contU].Nome;

            if (listaUsuario[contU].Imagem != null)
            {
                pictureBox1.BackgroundImage = null;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox1.Image = Image.FromFile(listaUsuario[contU].Imagem.FileName);
            } 
        }

        public class Postagem
        {
            public String Texto { get; set; }
            public int contUP { get; set; }
            public OpenFileDialog ImagemPostagem { get; set; }
            public int curtida { get; set; }
            public List<Comentario> listaComentarios { get; set; }
            public int numComentario { get; set; }
            public string Imagem { get; internal set; }
        }

        public class Comentario
        {
            public int contID { get; set; }
            public String Comentário { get; set; }
        }

        private void setaButton_Click(object sender, System.EventArgs e)
        {
            // Crie uma nova instância de Postagem
            Postagem novaPostagem = new Postagem
            {
                Texto = postBox.Text,
                contUP = contU,
                ImagemPostagem = imagemPost
            };

            if (string.IsNullOrEmpty(novaPostagem.Texto) && string.IsNullOrEmpty(novaPostagem.ImagemPostagem.FileName))
            {
                MessageBox.Show("Nenhum dos campos foi preenchido");
            }
            else
            {
                if (idCmnd >= 0) // Verifique se idCmnd é válido
                {
                    listaComunidade[idCmnd].listaPostagem.Add(novaPostagem);
                }
                else
                {
                    listaPostagem.Add(novaPostagem);
                }

                formController.Close();

                Form3 feed = new Form3(listaUsuario, contU, listaPostagem, listaConversa, listaComunidade);
                feed.Show();
                this.Close();
            }
        }

        private void inserirImagem_Click(object sender, EventArgs e)
        {
            imagemPost.Multiselect = false;
            imagemPost.Title = "Selecionar Imagem";
            imagemPost.Filter = "Imagens (*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF)|*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF|" +
                          "Todos os arquivos (*.*)|*.*";
            imagemPost.CheckFileExists = true;
            imagemPost.CheckPathExists = true;
            imagemPost.FilterIndex = 1;

            try
            {
                if (imagemPost.ShowDialog() == DialogResult.OK)
                {
                    if (imagemPreview != null)
                    {
                        imagemPreview.SizeMode = PictureBoxSizeMode.Zoom;
                        imagemPreview.Image = Image.FromFile(imagemPost.FileName);
                    }
                    else
                    {
                        MessageBox.Show("Controle PictureBox não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar a imagem: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmndBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (cmndBtn.Checked == true)
            {
                for (int i = 0; i < listaComunidade.Count; i++)
                {
                    for (int j = 0; j < listaComunidade[i].listaMembros.Count; j++)
                    {
                        if (listaComunidade[i].listaMembros[j].idMembro == contU)
                        {
                            Label nomeCmnd = new Label
                            {
                                AutoSize = true,
                                Font = new Font("Microsoft Sans Serif", 10),
                                Text = listaComunidade[i].Nome,
                                Location = new Point(3, 0),
                                Name = "" + i,

                            };
                            nomeCmnd.Click += new EventHandler(nomeCmnd_Click);
                            this.nomeCmnd = nomeCmnd;
                            flowLayoutPanel1.Controls.Add(nomeCmnd);
                        }
                    }
                }
            }
            else
            {
                comunidadeBox.Visible = false;
                flowLayoutPanel1.Controls.Clear();
            }
         }

        private void nomeCmnd_Click(object sender, EventArgs e)
        {
            // Limpa o fundo de todos os labels antes de mudar o fundo do label clicado
            foreach (Control control in flowLayoutPanel1.Controls)
            {
                if (control is Label)
                {
                    control.BackColor = Color.Transparent; // Restaura a cor de fundo original
                }
            }

            // Atualiza o texto do comunidadeBox
            Label clickedLabel = sender as Label; // Obtenha o controle que foi clicado
            if (clickedLabel != null)
            {
                comunidadeBox.Text = clickedLabel.Text; // Atualiza o texto do comunidadeBox
                comunidadeBox.Visible = true; // Torna o comunidadeBox visível

                // Muda o fundo do label clicado para cinza claro
                clickedLabel.BackColor = Color.LightGray;

                // Tenta obter o ID da comunidade a partir do Name do Label
                if (int.TryParse(clickedLabel.Name, out int idCmnd))
                {
                    this.idCmnd = idCmnd; // Atualiza a variável de instância
                }
                else
                {
                    MessageBox.Show("O ID da comunidade não está em um formato correto.");
                }
            }
        }
    }
}
