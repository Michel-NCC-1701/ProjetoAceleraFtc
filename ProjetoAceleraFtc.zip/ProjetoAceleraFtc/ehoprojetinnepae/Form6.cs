﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;
using static ehoprojetinnepae.Comunidades;
namespace ehoprojetinnepae
{
    public partial class Form6 : Form
    {
        private List<Postagem> listaPostagem = new List<Postagem>();
        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Comunidade> listaComunidades = new List<Comunidade>();
        private List<Conversas> listaConversa = new List<Conversas>();

        Form3 feed;
        Form10 comunidade;
        Form6 comentAba;

        int contP, contU, postIndex, idComunidade;

        private object value;

        public Form6(List<Usuario> listaUsuario, List<Postagem> listaPostagem, int contU, int contP, Form3 form3Cntrl, Form10 fomr10Cntrl,List<Conversas> listaConversa, List<Comunidade> listaComunidades, int idComunidade)
        {
            if (form3Cntrl != null)
            {
                feed = form3Cntrl;
            }
            else
            {
                comunidade = fomr10Cntrl;
            }

            comentAba = this;
            this.listaPostagem = listaPostagem;
            this.listaComunidades = listaComunidades;
            this.listaConversa = listaConversa;
            this.listaUsuario = listaUsuario;
            this.contU = contU;
            this.contP = contP;
            this.idComunidade = idComunidade;
            InitializeComponent();

            if (idComunidade > 0)
            {
                if (listaPostagem[contP].listaComentarios != null)
                {
                    criarComentarios();
                    panelComents.Visible = true;
                }
                else if (listaComunidades[idComunidade].listaPostagem[contP].listaComentarios != null)
                {
                    criarComentariosComunidade();
                    panelComents.Visible = true;
                }
            }
        }

        private void criarComentariosComunidade()
        {
            int locY = 5, locYTxt = 25, locL = 100;
            if (listaComunidades[idComunidade].listaPostagem[contP].listaComentarios != null)
            {
                locY += (100 * listaComunidades[idComunidade].listaPostagem[contP].listaComentarios.Count);
                locYTxt += (100 * listaComunidades[idComunidade].listaPostagem[contP].listaComentarios.Count);
                locL += (100 * listaComunidades[idComunidade].listaPostagem[contP].listaComentarios.Count);

                for (int i = 0; i < listaComunidades[idComunidade].listaPostagem[contP].listaComentarios.Count; i++)
                {
                    panelComents.Visible = false;

                    locY -= 100;
                    locYTxt -= 100;
                    locL -= 100;

                    Label comentarios = new Label();
                    comentarios.Name = "" + i;

                    comentarios.Location = new Point(5, locYTxt);
                    comentarios.AutoSize = false;
                    comentarios.Text = listaComunidades[idComunidade].listaPostagem[contP].listaComentarios[i].Comentário;
                    comentarios.TextAlign = ContentAlignment.TopLeft;
                    comentarios.Font = new Font("Microsoft Sans Serif", 10);
                    comentarios.Width = 350;
                    comentarios.Height = 70;
                    panelComents.Controls.Add(comentarios);

                    if (listaUsuario[listaComunidades[idComunidade].listaPostagem[contP].listaComentarios[i].contID].Imagem != null)
                    {
                        PictureBox postImgPerfil = new PictureBox();

                        postImgPerfil.Location = new Point(5, locY);
                        postImgPerfil.Width = 20;
                        postImgPerfil.Height = 20; ;
                        postImgPerfil.BorderStyle = BorderStyle.FixedSingle;
                        postImgPerfil.SizeMode = PictureBoxSizeMode.StretchImage;
                        postImgPerfil.Image = Image.FromFile(listaUsuario[listaComunidades[idComunidade].listaPostagem[contP].listaComentarios[i].contID].Imagem.FileName);
                        panelComents.Controls.Add(postImgPerfil);
                    }
                    else
                    {
                        //deixar sem imagem
                        PictureBox postImgPerfil = new PictureBox();

                        postImgPerfil.Location = new Point(5, locY);
                        postImgPerfil.Width = 20;
                        postImgPerfil.Height = 20;
                        postImgPerfil.BorderStyle = BorderStyle.FixedSingle;
                        postImgPerfil.SizeMode = PictureBoxSizeMode.StretchImage;
                        postImgPerfil.Image = Image.FromFile("Resources\\74472.png");
                        panelComents.Controls.Add(postImgPerfil);
                    }
                    //deixar com nome na postagem
                    Label postTxtPerfil = new Label();

                    postTxtPerfil.Location = new Point(25, locY);
                    postTxtPerfil.AutoSize = false;
                    postTxtPerfil.Text = listaUsuario[listaComunidades[idComunidade].listaPostagem[contP].listaComentarios[i].contID].Nome;
                    postTxtPerfil.TextAlign = ContentAlignment.TopLeft;
                    postTxtPerfil.Font = new Font("Microsoft Sans Serif", 10);
                    postTxtPerfil.Width = 242;
                    postTxtPerfil.Height = 18;
                    panelComents.Controls.Add(postTxtPerfil);

                    Panel postL = new Panel();

                    postL.Location = new Point(0, locL);
                    postL.Width = 382;
                    postL.Height = 1;
                    postL.BackColor = Color.Gray;
                    panelComents.Controls.Add(postL);
                }
            }
        }

        private void criarComentarios() 
        {
            int locY = 5, locYTxt = 25, locL = 100;
            if (listaPostagem[contP].listaComentarios != null)
            {
                locY += (100 * listaPostagem[contP].listaComentarios.Count);
                locYTxt += (100 * listaPostagem[contP].listaComentarios.Count);
                locL += (100 * listaPostagem[contP].listaComentarios.Count);

                this.listaPostagem[contP].listaComentarios = listaPostagem[contP].listaComentarios;
                for (int i = 0; i < this.listaPostagem[contP].listaComentarios.Count; i++)
                {
                    panelComents.Visible = false;

                    locY -= 100;
                    locYTxt -= 100;
                    locL -= 100;

                    Label comentarios = new Label();
                    comentarios.Name = "" + i;

                    comentarios.Location = new Point(5, locYTxt);
                    comentarios.AutoSize = false;
                    comentarios.Text = listaPostagem[contP].listaComentarios[i].Comentário;
                    comentarios.TextAlign = ContentAlignment.TopLeft;
                    comentarios.Font = new Font("Microsoft Sans Serif", 10);
                    comentarios.Width = 350;
                    comentarios.Height = 70;
                    panelComents.Controls.Add(comentarios);

                    if (listaUsuario[listaPostagem[contP].listaComentarios[i].contID].Imagem != null)
                    {
                        PictureBox postImgPerfil = new PictureBox();

                        postImgPerfil.Location = new Point(5, locY);
                        postImgPerfil.Width = 20;
                        postImgPerfil.Height = 20; ;
                        postImgPerfil.BorderStyle = BorderStyle.FixedSingle;
                        postImgPerfil.SizeMode = PictureBoxSizeMode.StretchImage;
                        postImgPerfil.Image = Image.FromFile(listaUsuario[listaPostagem[contP].listaComentarios[i].contID].Imagem.FileName);
                        panelComents.Controls.Add(postImgPerfil);
                    }
                    else
                    {
                        //deixar sem imagem
                        PictureBox postImgPerfil = new PictureBox();

                        postImgPerfil.Location = new Point(5, locY);
                        postImgPerfil.Width = 20;
                        postImgPerfil.Height = 20;
                        postImgPerfil.BorderStyle = BorderStyle.FixedSingle;
                        postImgPerfil.SizeMode = PictureBoxSizeMode.StretchImage;
                        postImgPerfil.Image = Image.FromFile("Resources\\74472.png");
                        panelComents.Controls.Add(postImgPerfil);
                    }
                    //deixar com nome na postagem
                    Label postTxtPerfil = new Label();

                    postTxtPerfil.Location = new Point(25, locY);
                    postTxtPerfil.AutoSize = false;
                    postTxtPerfil.Text = listaUsuario[listaPostagem[contP].listaComentarios[i].contID].Nome;
                    postTxtPerfil.TextAlign = ContentAlignment.TopLeft;
                    postTxtPerfil.Font = new Font("Microsoft Sans Serif", 10);
                    postTxtPerfil.Width = 242;
                    postTxtPerfil.Height = 18;
                    panelComents.Controls.Add(postTxtPerfil);

                    Panel postL = new Panel();

                    postL.Location = new Point(0, locL);
                    postL.Width = 382;
                    postL.Height = 1;
                    postL.BackColor = Color.Gray;
                    panelComents.Controls.Add(postL);
                }
            }
        }

        private void enviarButton_Click_1(object sender, EventArgs e)
        {
            if (feed != null)
            {
                if (listaPostagem[contP].listaComentarios == null)
                {
                    listaPostagem[contP].listaComentarios = new List<Comentario>();
                }

                Comentario comentario = new Comentario();

                if (comentarioBox.Text != null && comentarioBox.Text != "")
                {
                    comentario.Comentário = comentarioBox.Text;
                    comentario.contID = contU;
                    listaPostagem[contP].numComentario++;
                    listaPostagem[contP].listaComentarios.Add(comentario);

                    panelComents.Controls.Clear();

                    criarComentarios();

                    panelComents.Visible = true;

                    comentarioBox.Text = "";

                    feed.limparFeed();
                    feed.criarPostagem();
                }
            }
            else if (comunidade != null)
            {
                if (listaComunidades[idComunidade].listaPostagem[contP].listaComentarios == null)
                {
                    listaComunidades[idComunidade].listaPostagem[contP].listaComentarios = new List<Comentario>();
                }

                Comentario comentario = new Comentario();

                if (comentarioBox.Text != null && comentarioBox.Text != "")
                {
                    comentario.Comentário = comentarioBox.Text;
                    comentario.contID = contU;
                    listaComunidades[idComunidade].listaPostagem[contP].numComentario++;
                    listaComunidades[idComunidade].listaPostagem[contP].listaComentarios.Add(comentario);

                    panelComents.Controls.Clear();

                    criarComentariosComunidade();

                    panelComents.Visible = true;

                    comentarioBox.Text = "";

                    comunidade.limparFeed();
                    comunidade.exibirPost();
                }
            }
        }
    }
}
