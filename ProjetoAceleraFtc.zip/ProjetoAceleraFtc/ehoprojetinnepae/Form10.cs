﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using static ehoprojetinnepae.Comunidades;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;

namespace ehoprojetinnepae
{
    public partial class Form10 : Form
    {
        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Postagem> listaPostagens = new List<Postagem>();
        private List<Conversas> listaConversas = new List<Conversas>();
        private List<Comunidade> listaComunidades = new List<Comunidade>();

        bool buttonClicado = false;

        Panel panelNotificacao = new Panel();
        Button buttonRecusar;
        Button buttonAceitar;

        Form10 formCntrl;

        int contU, idComunidade;
        public Form10(List<Usuario> listaUsuario, int contU, List<Postagem> listaPostagens, List<Conversas> listaConversas, Comunidades cntrl, List<Comunidade> listaComunidades, int idComunidade)
        {
            this.listaComunidades = listaComunidades;
            this.listaConversas = listaConversas;
            this.listaPostagens = listaPostagens;
            this.listaUsuario = listaUsuario;
            this.idComunidade = idComunidade;
            this.contU = contU;
            formCntrl = this;

            InitializeComponent();

            if (listaUsuario[contU].Imagem != null)
            {
                pictureBox8.BackgroundImage = null;
                pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox8.Image = Image.FromFile(listaUsuario[contU].Imagem.FileName);
            }

            editarLateral();
            criarMembros();
            exibirPost();
            atualizarBtn();
            ntfVermelho();
        }

        public void exibirPost()
        {
            try
            {
                int locY = 0;
                locY += (381 * listaComunidades[idComunidade].listaPostagem.Count);
                for (int i = 0; i < listaComunidades[idComunidade].listaPostagem.Count; i++)
                {
                    locY -= 381;
                    Panel panel = new Panel
                    {
                        Location = new Point(0, locY),
                        Size = new Size(838, 381),
                    };
                    panelPost.Controls.Add(panel);

                    // Carregar imagem do usuário
                    string caminhoImagemUsuario = listaUsuario[listaComunidades[idComunidade].listaPostagem[i].contUP].Imagem?.FileName;
                    if (caminhoImagemUsuario != null && File.Exists(caminhoImagemUsuario))
                    {
                        PictureBox pictureBox = new PictureBox
                        {
                            Location = new Point(185, 11),
                            Size = new Size(45, 45),
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            BorderStyle = BorderStyle.FixedSingle,
                            Image = Image.FromFile(caminhoImagemUsuario)
                        };
                        panel.Controls.Add(pictureBox);
                    }
                    else
                    {
                        PictureBox pictureBox = new PictureBox
                        {
                            Location = new Point(185, 11),
                            Size = new Size(45, 45),
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            BorderStyle = BorderStyle.FixedSingle,
                            Image = Image.FromFile("Resources\\74472.png")
                        };
                        panel.Controls.Add(pictureBox);
                    }

                    // Carregar imagem da postagem
                    string caminhoImagemPostagem = listaComunidades[idComunidade].listaPostagem[i].ImagemPostagem.FileName;
                    PictureBox picturePost = new PictureBox
                    {
                        Location = new Point(185, 60),
                        Size = new Size(400, 200),
                        SizeMode = PictureBoxSizeMode.Zoom
                    };

                    if (File.Exists(caminhoImagemPostagem))
                    {
                        picturePost.Image = Image.FromFile(caminhoImagemPostagem);
                    }
                    else
                    {
                        // Defina uma imagem padrão se a imagem da postagem não existir
                        picturePost.Image = Image.FromFile("Resources\\imagem-padrao.png");
                    }

                    panel.Controls.Add(picturePost);

                    // Adicionar o restante dos controles (labels, curtidas, etc.) aqui...
                    Label label = new Label
                    {
                        Location = new Point(231, 14),
                        Size = new Size(349, 45),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = listaUsuario[listaComunidades[idComunidade].listaPostagem[i].contUP].Nome
                    };

                    panel.Controls.Add(label);

                    Label labelPost = new Label
                    {
                        Location = new Point(185, 265),
                        Size = new Size(405, 40),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = listaComunidades[idComunidade].listaPostagem[i].Texto
                    };

                    panel.Controls.Add(labelPost);

                    bool curtida = false;

                    if (listaUsuario[contU].comunidadeUsuario != null)
                    {
                        for (int u = 0; u < listaUsuario[contU].comunidadeUsuario.Count; u++)
                        {
                            if (listaUsuario[contU].comunidadeUsuario[u].contPost == i && listaUsuario[contU].comunidadeUsuario[u].idComunidades == idComunidade) // Verifique se o índice está correto
                            {
                                curtida = listaUsuario[contU].comunidadeUsuario[u].postagemCurtiu;
                                break;
                            }
                        }
                    }

                    // Defina a imagem de curtida com base na verificação
                    PictureBox imgCurtida = new PictureBox
                    {
                        Name = "" + i,
                        Location = new Point(185, 308),
                        Size = new Size(40, 40),
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Image = curtida ? Image.FromFile("Resources\\like-preenchido.png") : Image.FromFile("Resources\\like.png"),
                    };
                    panel.Controls.Add(imgCurtida);
                    imgCurtida.Click += new EventHandler(pictureCurtida_Click);

                    Label lblCurtida = new Label
                    {
                        Name = "lblCurtida" + i, // Nome único baseado no índice da postagem
                        Location = new Point(231, 322),
                        Size = new Size(50, 20),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = "" + listaComunidades[idComunidade].listaPostagem[i].curtida
                    };

                    panel.Controls.Add(lblCurtida);

                    PictureBox pictureComentario = new PictureBox
                    {
                        Location = new Point(288, 308),
                        Size = new Size(40, 40),
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Image = Image.FromFile("Resources\\bate-papo.png"),
                    };
                    pictureComentario.Name = i.ToString(); // Certifique-se de que é uma string numérica

                    pictureComentario.Click += new EventHandler(pictureComentario_Click);
                    panel.Controls.Add(pictureComentario);

                    Label lblComent = new Label
                    {
                        Location = new Point(334, 322),
                        Size = new Size(50, 20),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = "" + listaComunidades[idComunidade].listaPostagem[i].numComentario
                    };

                    panel.Controls.Add(lblComent);

                    Panel linhaDesign = new Panel
                    {
                        Location = new Point(0, 379),
                        Size = new Size(838, 1),
                        BackColor = Color.Indigo
                    };

                    panel.Controls.Add(linhaDesign);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao exibir as postagens: " + ex.Message);
            }
        }

        private void pictureComentario_Click(object sender, EventArgs e)
        {
            PictureBox imgComent = (PictureBox)sender;
            int postIndex = int.Parse(imgComent.Name);
            Form6 abaComentarios = new Form6(listaUsuario, listaPostagens, contU, postIndex, null, this, listaConversas, listaComunidades, idComunidade);
            abaComentarios.Show();
        }

        private void pictureCurtida_Click(object sender, EventArgs e)
        {
            PictureBox imgCurtida = (PictureBox)sender;
            int postIndex = int.Parse(imgCurtida.Name); // Obtenha o índice da postagem
            CurtirPostagem(postIndex, imgCurtida);
        }

        private void CurtirPostagem(int postIndex, PictureBox imgCurtida)
        {
            // Inicializa a lista de postagens do usuário se não existir
            if (listaUsuario[contU].comunidadeUsuario == null)
            {
                listaUsuario[contU].comunidadeUsuario = new List<ComunidadeUsuario>();
            }

            bool postagemCurtida = false;

            // Verifica se a postagem já foi curtida e se pertence à comunidade atual
            for (int u = 0; u < listaUsuario[contU].comunidadeUsuario.Count; u++)
            {
                if (listaUsuario[contU].comunidadeUsuario[u].contPost == postIndex &&
                    listaUsuario[contU].comunidadeUsuario[u].idComunidades == idComunidade) // Verifica se a postagem é da comunidade atual
                {
                    postagemCurtida = true;

                    if (listaUsuario[contU].comunidadeUsuario[u].postagemCurtiu)
                    {
                        // Descurtir
                        imgCurtida.Image = Image.FromFile("Resources\\like.png");
                        if (listaComunidades[idComunidade].listaPostagem[postIndex].curtida > 0) // Verifica se a contagem de curtidas é maior que 0
                        {
                            listaComunidades[idComunidade].listaPostagem[postIndex].curtida--;
                        }
                        listaUsuario[contU].comunidadeUsuario[u].postagemCurtiu = false;
                    }
                    else
                    {
                        // Curtir
                        imgCurtida.Image = Image.FromFile("Resources\\like-preenchido.png");
                        listaComunidades[idComunidade].listaPostagem[postIndex].curtida++;
                        listaUsuario[contU].comunidadeUsuario[u].postagemCurtiu = true;
                    }
                    break;
                }
            }

            // Se a postagem não foi curtida, adiciona uma nova entrada
            if (!postagemCurtida)
            {
                    ComunidadeUsuario comunidadeUsuario = new ComunidadeUsuario
                    {
                        idComunidades = idComunidade,
                        contPost = postIndex,
                        postagemCurtiu = true
                    };
                    listaUsuario[contU].comunidadeUsuario.Add(comunidadeUsuario);
                    imgCurtida.Image = Image.FromFile("Resources\\like-preenchido.png");
                    listaComunidades[idComunidade].listaPostagem[postIndex].curtida++;
                
            }

            // Atualiza o número de likes no Label correspondente
            Label lblCurtida = (Label)panelPost.Controls.Find("lblCurtida" + postIndex, true).FirstOrDefault();
            if (lblCurtida != null)
            {
                lblCurtida.Text = listaComunidades[idComunidade].listaPostagem[postIndex].curtida.ToString(); // Atualiza o texto do Label
            }
        }

        public void atualizarBtn()
        {
            // Verifica se o usuário é membro da comunidade
            bool isMembro = listaComunidades[idComunidade].listaMembros.Exists(m => m.idMembro == contU);

            if (isMembro)
            {
                button1.BackColor = Color.Gray;
                button1.Text = "Sair";

                // Se o usuário for o criador da comunidade, muda a cor para vermelho
                if (listaComunidades[idComunidade].idCriador == contU)
                {
                    button1.BackColor = Color.Red;
                    button1.Text = "Excluir";
                }
            }
            else
            {
                button1.BackColor = Color.MediumPurple;
                button1.Text = "Entrar";
            }
        }

        public void editarLateral()
        {
            pictureBoxCmnd.Image = Image.FromFile(listaComunidades[idComunidade].Imagem.FileName);
            pictureBoxCmnd.SizeMode = PictureBoxSizeMode.StretchImage;
            labelCmnd.Text = listaComunidades[idComunidade].Nome;
            labelDesc.Text = listaComunidades[idComunidade].Descricao;
        }

        public void criarMembros()
        {
            int locY = 20;
            for (int i = 0; i < listaComunidades[idComunidade].listaMembros.Count; i++)
            {
                PictureBox imgMembros = new PictureBox
                {
                    BorderStyle = BorderStyle.FixedSingle,
                    Size = new Size(50, 50),
                    Location = new Point(6, locY)
                };

                imgMembros.SizeMode = PictureBoxSizeMode.StretchImage;

                if (listaUsuario[listaComunidades[idComunidade].listaMembros[i].idMembro].Imagem != null)
                {
                    imgMembros.Image = Image.FromFile(listaUsuario[listaComunidades[idComunidade].listaMembros[i].idMembro].Imagem.FileName);
                }
                else
                {
                    imgMembros.Image = Image.FromFile("Resources\\74472.png");
                }

                Label nomeMembros = new Label
                {
                    Text = listaUsuario[listaComunidades[idComunidade].listaMembros[i].idMembro].Nome,
                    Font = new Font("Microsoft Sans Serif", 14),
                    AutoSize = false,
                    Size = new Size(100, 40),
                    Location = new Point(55, locY)
                };

                panelMembros.Controls.Add(imgMembros);
                panelMembros.Controls.Add(nomeMembros);


                locY += 55;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form3 feed = new Form3(listaUsuario, contU, listaPostagens, listaConversas, listaComunidades);
            feed.Show();
            this.Close();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            Form4 perfilUsuario = new Form4(listaUsuario, contU, contU, listaPostagens, listaConversas, listaComunidades);
            perfilUsuario.Show();
            this.Close();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Form7 amigos = new Form7(listaUsuario, contU, listaPostagens, listaConversas, listaComunidades);
            amigos.Show();
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Comunidades comunidades = new Comunidades(listaUsuario, contU, listaPostagens, listaConversas, listaComunidades);
            comunidades.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 postagemUsuario = new Form5(listaUsuario, contU, listaPostagens, this, listaConversas, listaComunidades);
            postagemUsuario.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form2 voltarLogin = new Form2(null, listaUsuario, listaPostagens, listaConversas, listaComunidades);
            voltarLogin.Show();
            this.Close();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (buttonClicado == false)
            {
                criarPanelNotificacao();
                buttonClicado = true;

                if (panelNotificacao.Visible == false)
                {
                    panelNotificacao.Visible = true;
                }
            }
            else if (buttonClicado == true)
            {
                panelNotificacao.Visible = false;
                buttonClicado = false;
            }
        }

        public void criarPanelNotificacao()
        {
            panelNotificacao.Location = new Point(95, 320);
            panelNotificacao.Size = new Size(265, 135);
            panelNotificacao.BackColor = Color.White;
            panelNotificacao.AutoScroll = true;
            panelNotificacao.BorderStyle = BorderStyle.FixedSingle;

            Controls.Add(panelNotificacao);
            panelNotificacao.BringToFront();

            if (listaUsuario[contU].listaAmigos != null)
            {
                int locPerf = 5, locButton = 45;

                locPerf += (100 * listaUsuario[contU].listaAmigos.Count);
                locButton += (100 * listaUsuario[contU].listaAmigos.Count);

                buttonClicado = true;

                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    locPerf -= 100;
                    locButton -= 100;
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        if (listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem != null)
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile(listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem.FileName);
                            panelNotificacao.Controls.Add(imgNtf);
                        }
                        else
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile("Resources\\74472.png");
                            panelNotificacao.Controls.Add(imgNtf);
                        }

                        Label txtNtf = new Label();

                        txtNtf.Location = new Point(50, locPerf);
                        txtNtf.Text = "" + listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Nome + " enviou uma solicitação de amizade.";
                        txtNtf.Font = new Font("Microsoft Sans Serif", 10);
                        txtNtf.Width = 200;
                        txtNtf.Height = 40;
                        panelNotificacao.Controls.Add(txtNtf);

                        buttonAceitar = new Button();
                        buttonAceitar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo; ;

                        buttonAceitar.Location = new Point(50, locButton);
                        buttonAceitar.Width = 60;
                        buttonAceitar.Height = 30;
                        buttonAceitar.Text = "Aceitar";
                        buttonAceitar.BackColor = Color.MediumPurple;
                        buttonAceitar.FlatStyle = FlatStyle.Popup;
                        buttonAceitar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonAceitar);
                        buttonAceitar.Click += new EventHandler(buttonAceitar_Click);

                        buttonRecusar = new Button();
                        buttonRecusar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo;

                        buttonRecusar.Location = new Point(120, locButton);
                        buttonRecusar.Width = 60;
                        buttonRecusar.Height = 30;
                        buttonRecusar.Text = "Recusar";
                        buttonRecusar.BackColor = Color.Gray;
                        buttonRecusar.FlatStyle = FlatStyle.Popup;
                        buttonRecusar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonRecusar);
                        buttonRecusar.Click += new EventHandler(buttonRecusar_Click);
                    }
                }
            }
        }

        private void buttonAceitar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {
                    listaUsuario[contU].listaAmigos[i].amizade = true;
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNotificacao.Visible = false;

                    break;
                }
            }

            if (listaUsuario[idAmigo].listaAmigos == null)
            {
                listaUsuario[idAmigo].listaAmigos = new List<Amigos>();
            }

            Amigos amigos = new Amigos
            {
                idAmigo = contU,
                solicitacaoRecebida = false,
                amizade = true,
            };

            listaUsuario[idAmigo].listaAmigos.Add(amigos);

            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNotificacao.Controls.Clear();
            ntfVermelho();
        }

        public void ntfVermelho()
        {
            if (listaUsuario[contU].listaAmigos != null)
            {
                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        pingouNotificacao.Visible = true;
                    }

                }
            }
        }

        private void buttonRecusar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNotificacao.Visible = false;
                    break;
                }
            }
            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNotificacao.Controls.Clear();
            ntfVermelho();
        }

        public void limparFeed()
        {
            panelPost.Controls.Clear();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            bool isMembro = listaComunidades[idComunidade].listaMembros.Exists(m => m.idMembro == contU);

            if (!isMembro)
            {
                // Adiciona o usuário como membro
                Membros novosMembros = new Membros
                {
                    idMembro = contU
                };

                listaComunidades[idComunidade].listaMembros.Add(novosMembros);
                panelMembros.Controls.Clear();
                criarMembros();
            }
            else
            {
                // Verifica se o botão está configurado para "Excluir"
                if (button1.Text == "Excluir")
                {
                    // Remove a comunidade da lista
                    listaComunidades.RemoveAt(idComunidade);

                    Comunidades comunidades = new Comunidades(listaUsuario, contU, listaPostagens, listaConversas, listaComunidades);
                    comunidades.Show();
                    this.Close();
                    return;
                }

                // Se o usuário já é membro, remove o membro da lista
                listaComunidades[idComunidade].listaMembros.RemoveAll(m => m.idMembro == contU);
                panelMembros.Controls.Clear();
                criarMembros();
            }

            // Atualiza o botão após a adição ou remoção
            atualizarBtn();
        }
    }
}

