﻿namespace ehoprojetinnepae
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comentarioBox = new System.Windows.Forms.TextBox();
            this.enviarButton = new System.Windows.Forms.Button();
            this.panelComents = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // comentarioBox
            // 
            this.comentarioBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.comentarioBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comentarioBox.Location = new System.Drawing.Point(5, 346);
            this.comentarioBox.Multiline = true;
            this.comentarioBox.Name = "comentarioBox";
            this.comentarioBox.Size = new System.Drawing.Size(352, 38);
            this.comentarioBox.TabIndex = 0;
            // 
            // enviarButton
            // 
            this.enviarButton.BackColor = System.Drawing.Color.Transparent;
            this.enviarButton.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.next;
            this.enviarButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.enviarButton.Location = new System.Drawing.Point(358, 343);
            this.enviarButton.Name = "enviarButton";
            this.enviarButton.Size = new System.Drawing.Size(45, 45);
            this.enviarButton.TabIndex = 1;
            this.enviarButton.UseVisualStyleBackColor = false;
            this.enviarButton.Click += new System.EventHandler(this.enviarButton_Click_1);
            // 
            // panelComents
            // 
            this.panelComents.AutoScroll = true;
            this.panelComents.BackColor = System.Drawing.Color.White;
            this.panelComents.Location = new System.Drawing.Point(12, 12);
            this.panelComents.Name = "panelComents";
            this.panelComents.Size = new System.Drawing.Size(382, 328);
            this.panelComents.TabIndex = 2;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(406, 389);
            this.Controls.Add(this.panelComents);
            this.Controls.Add(this.enviarButton);
            this.Controls.Add(this.comentarioBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comentários";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox comentarioBox;
        private System.Windows.Forms.Button enviarButton;
        private System.Windows.Forms.Panel panelComents;
    }
}