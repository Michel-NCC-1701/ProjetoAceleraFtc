﻿//VERSÃO FINAL DO PROJETO

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static ehoprojetinnepae.Comunidades;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;

namespace ehoprojetinnepae
{
    public partial class Form1 : Form
    {
        private List<Postagem> listaPostagem = new List<Postagem>();
        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Conversas> listaConversa = new List<Conversas> ();
        private List<Comunidade> listaComunidades = new List<Comunidade>();

        Usuario usuario = new Usuario();
        PostagemUsuario postagemUsuario = new PostagemUsuario(); 

        public Form1(List<Usuario> listaUsuario, List<Postagem> listaPostagem, List<Conversas> listaConversa, List<Comunidade> listaComunidades)
        {
            InitializeComponent();
            
            this.listaComunidades = listaComunidades;
            
            this.listaConversa = listaConversa;
            
            if (listaUsuario != null)
            {
                this.listaUsuario = listaUsuario;
            }

            if (listaPostagem != null)
            {
                this.listaPostagem = listaPostagem;
            }
        }

        public class Usuario 
        {
            public String Nome { get; set; } 
            public String Email { get; set; } 
            public String Senha { get; set; }
            public OpenFileDialog Imagem { get; set; }
            public List<PostagemUsuario> postagensUsuario { get; set; }
            public List<ComunidadeUsuario> comunidadeUsuario { get; set; }
            public List<Amigos> listaAmigos { get; set; }
        }

        public class ComunidadeUsuario
        {
            public int idComunidades { get; set; }
            public int contPost { get; set; }
            public bool postagemCurtiu { get; set; }
        }

        public class PostagemUsuario
        {
            public int contPost { get; set; }
            public bool postagemCurtiu { get; set; }
        }

        public class Amigos
        {
            public int idAmigo { get; set; }
            public bool solicitacaoRecebida {get ; set;}
            public bool amizade { get ; set;}
        }

        private void registrarUsuario(int op)
        {
            if (op == 0)
            {
                if (string.IsNullOrWhiteSpace(usuario.Nome) ||
                string.IsNullOrWhiteSpace(usuario.Email) ||
                string.IsNullOrWhiteSpace(usuario.Senha))
                {
                    MessageBox.Show("Todos os campos devem ser preenchidos.");
                    return;
                }

                usuario.Imagem = null;

                if (!usuario.Email.Contains("@"))
                {
                    MessageBox.Show("Tipo de e-mail inválido");
                }
                else
                {
                    MessageBox.Show("Os dados foram registrados!");
                    Form2 form2 = new Form2(usuario, listaUsuario, listaPostagem, listaConversa, listaComunidades);
                    form2.Show();
                    this.Hide();
                }
            }
            else if (op == 1)
            {
                Form2 form2 = new Form2(usuario, listaUsuario, listaPostagem, listaConversa, listaComunidades);
                form2.Show();
                this.Hide();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            bool cadastrado = false;
            if (listaUsuario != null)
            {
                foreach (var usuario in listaUsuario)
                {
                    if (emailBox.Text == usuario.Email)
                    {
                        MessageBox.Show("E-mail já cadastrado no sistema");
                        cadastrado = true;
                        break; 
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(nomeBox.Text) ||
                string.IsNullOrWhiteSpace(senhaBox.Text) ||
                string.IsNullOrWhiteSpace(emailBox.Text) ||
                string.IsNullOrWhiteSpace(cSenhaBox.Text))
            {
                MessageBox.Show("Algum dos campos não foi preenchido");
                return;
            }

            if (senhaBox.Text != cSenhaBox.Text)
            {
                MessageBox.Show("As senhas não coincidem!");
            }
            else if (!cadastrado)
            {
                usuario.Nome = nomeBox.Text;
                usuario.Email = emailBox.Text;
                usuario.Senha = senhaBox.Text;
                registrarUsuario(0);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (exibeSenha.Checked == true)
            {
                senhaBox.PasswordChar = '\0';
                cSenhaBox.PasswordChar = '\0';
            } 
            else
            {
                senhaBox.PasswordChar = '*';
                cSenhaBox.PasswordChar= '*';
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            registrarUsuario(1);
        }
    }
}