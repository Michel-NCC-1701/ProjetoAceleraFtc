﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ehoprojetinnepae
{
    public partial class Flappy : Form
    {
        private int birdX = 100; // Posição X do pássaro
        private int birdY = 200; // Posição Y do pássaro
        private int birdWidth = 40; // Largura do pássaro
        private int birdHeight = 40; // Altura do pássaro
        private int birdVelocityY = 0; // Velocidade vertical do pássaro
        private int gravity = 1; // Gravidade do pássaro
        private bool isFlapping = false; // Se o pássaro está subindo

        private List<Rectangle> pipes; // Lista de canos
        private int pipeWidth = 60; // Largura dos canos
        private int pipeGap = 150; // Espaço entre os canos
        private int pipeSpeed = 5; // Velocidade dos canos

        private int score = 0; // Pontuação do jogo

        private Timer gameTimer;

        public Flappy()
        {
            InitializeComponent();

            this.Text = "Flappy Bird Clone";
            this.ClientSize = new Size(800, 600);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Ativar double buffering
            this.DoubleBuffered = true;

            pipes = new List<Rectangle>();

            // Iniciar o timer do jogo
            gameTimer = new Timer();
            gameTimer.Interval = 20; // Atualiza a cada 20ms (50 FPS)
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            this.KeyDown += Form1_KeyDown;
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            // Atualiza a posição do pássaro
            if (isFlapping)
            {
                birdVelocityY = -10; // O pássaro sobe
                isFlapping = false;
            }
            birdVelocityY += gravity; // Aplica a gravidade
            birdY += birdVelocityY; // Atualiza a posição do pássaro

            // Gera os canos
            GeneratePipes();

            // Move os canos
            for (int i = pipes.Count - 1; i >= 0; i--)
            {
                pipes[i] = new Rectangle(pipes[i].X - pipeSpeed, pipes[i].Y, pipeWidth, pipes[i].Height);

                // Remove os canos que saíram da tela
                if (pipes[i].X + pipeWidth < 0)
                {
                    pipes.RemoveAt(i);
                    score++; // Incrementa a pontuação quando o pássaro passa por um cano
                }
            }

            // Verifica colisões
            if (birdY + birdHeight > this.ClientSize.Height || birdY < 0 || CheckCollisions())
            {
                gameTimer.Stop(); // Para o jogo em caso de colisão
            }

            this.Invalidate(); // Força a tela a ser desenhada novamente
        }

        private void GeneratePipes()
        {
            // Cria um novo cano se necessário
            if (pipes.Count == 0 || pipes[pipes.Count - 1].X < this.ClientSize.Width - 300)
            {
                Random rand = new Random();
                int pipeHeight = rand.Next(100, 400); // Altura aleatória do cano
                pipes.Add(new Rectangle(this.ClientSize.Width, 0, pipeWidth, pipeHeight)); // Canos superiores
                pipes.Add(new Rectangle(this.ClientSize.Width, pipeHeight + pipeGap, pipeWidth, this.ClientSize.Height - pipeHeight - pipeGap)); // Canos 
            }
        }

        private bool CheckCollisions()
        {
            // Verifica se o pássaro bateu em algum cano
            Rectangle birdRect = new Rectangle(birdX, birdY, birdWidth, birdHeight);
            foreach (var pipe in pipes)
            {
                if (birdRect.IntersectsWith(pipe))
                {
                    return true; // Colidiu com um cano
                }
            }
            return false;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // O pássaro sobe quando a tecla de espaço é pressionada
            if (e.KeyCode == Keys.Space)
            {
                isFlapping = true;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;

            // Desenha o fundo
            g.Clear(Color.Cyan);

            // Desenha o solo (chão)
            g.FillRectangle(Brushes.Green, 0, this.ClientSize.Height - 50, this.ClientSize.Width, 50);

            // Desenha o pássaro
            g.FillEllipse(Brushes.MediumPurple, birdX, birdY, birdWidth, birdHeight);

            // Desenha os canos
            foreach (var pipe in pipes)
            {
                g.FillRectangle(Brushes.Indigo, pipe);
            }
        }
    }
}
