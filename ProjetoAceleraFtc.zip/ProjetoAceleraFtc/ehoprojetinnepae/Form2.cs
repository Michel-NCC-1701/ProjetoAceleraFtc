﻿using ehoprojetinnepae;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;
using static ehoprojetinnepae.Comunidades;
using System.Collections.Generic;
using System.Windows.Forms;
using System;

namespace ehoprojetinnepae
{
    public partial class Form2 : Form
    {
        private List<Usuario> listaUsuario = new List<Usuario>(); private List<Conversas> listaConversa = new List<Conversas>(); private List<Comunidade> listaComunidades = new List<Comunidade>(); private List<Postagem> listaPostagem;

        public Form2(Usuario usuario, List<Usuario> listaUsuario, List<Postagem> listaPostagem, List<Conversas> listaConversa, List<Comunidade> listaComunidades)
        {
            this.listaComunidades = listaComunidades;

            this.listaConversa = listaConversa;

            if (listaPostagem != null)
            {
                this.listaPostagem = listaPostagem;
            }
            if (listaUsuario != null)
            {
                this.listaUsuario = listaUsuario;
            }

            if (usuario != null)
            {
                this.listaUsuario.Add(usuario);
            }
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            bool validacao = false;
            if (senhaBox.Text == "" || emailBox.Text == "")
            {
                MessageBox.Show("Algum dos campos não foi preenchido");
            }
            else
            {
                for (i = 0; i < listaUsuario.Count; i++)
                {
                    if (emailBox.Text == listaUsuario[i].Email && senhaBox.Text == listaUsuario[i].Senha)
                    {
                        validacao = true;
                        break;
                    }
                }

                if (validacao == true)
                {
                    MessageBox.Show("Login realizado com sucesso!");

                    Form3 feed = new Form3(listaUsuario, i, listaPostagem, listaConversa, listaComunidades);
                    feed.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Houve uma incoerência nos dados");
                }
            }
        }

        private void exibeSenha_CheckedChanged(object sender, EventArgs e)
        {
            if (exibeSenha.Checked == true)
            {
                senhaBox.PasswordChar = '\0';
            }
            else
            {
                senhaBox.PasswordChar = '*';
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 cadastro = new Form1(listaUsuario, listaPostagem, listaConversa, listaComunidades);
            cadastro.WindowState = FormWindowState.Normal;
            cadastro.Show();
            this.Close();
        }
    }
}