﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;

namespace ehoprojetinnepae
{
    public partial class Comunidades : Form
    {
        private OpenFileDialog imgCmnd = new OpenFileDialog();

        bool buttonClicado = false;

        Panel panelNotificacao = new Panel();
        Button buttonRecusar;
        Button buttonAceitar;

        private List<Usuario> listaUsuario = new List<Usuario> ();
        private List<Postagem> listaPostagens = new List<Postagem> ();
        private List<Conversas> listaConversas = new List<Conversas> ();
        private List<Comunidade> listaComunidades = new List<Comunidade> ();

        int contU;
        public Comunidades(List<Usuario> listaUsuario, int contU, List<Postagem> listaPostagens, List<Conversas> listaConversas, List<Comunidade> listaComunidades)
        {
            this.listaUsuario = listaUsuario;
            this.contU = contU;
            this.listaPostagens = listaPostagens;
            this.listaConversas = listaConversas;

            InitializeComponent();

            if (listaUsuario[contU].Imagem != null)
            {
                pictureBox8.BackgroundImage = null;
                pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox8.Image = Image.FromFile(listaUsuario[contU].Imagem.FileName);
            }

            if (listaComunidades != null)
            {
                this.listaComunidades = listaComunidades;
                exibirComunidade();
            }
            ntfVermelho();
        }

        public class Comunidade
        {
            public String Nome { get; set; }
            public String Descricao { get; set; }
            public int idCriador { get; set; }
            public OpenFileDialog Imagem { get; set; }
            public List<Membros> listaMembros { get; set; } = new List<Membros>();
            public List<Postagem> listaPostagem { get; set; } = new List<Postagem>();
        }

        public class Membros
        {
            public int idMembro { get; set; }
        }

        public void exibirComunidade()
        {
            pnlComunidade.AutoScroll = true;
            pnlComunidade.WrapContents = true;
            pnlComunidade.FlowDirection = FlowDirection.LeftToRight;
            pnlComunidade.Padding = new Padding(2);

            for (int i = 0; i < listaComunidades.Count; i++)
            {
                Panel cmnd = new Panel
                {
                    Name = "" + i,
                    Margin = new Padding(1),
                    Size = new Size(230, 250),
                    BackColor = Color.White,
                    BorderStyle = BorderStyle.FixedSingle
                };
                cmnd.Click += new EventHandler(cmnd_Click);

                pnlComunidade.Controls.Add(cmnd);

                PictureBox imgC = new PictureBox
                {
                    BorderStyle = BorderStyle.FixedSingle,
                    Location = new Point(24, 9),
                    Size = new Size(180, 180),
                    Image = Image.FromFile(listaComunidades[i].Imagem.FileName),
                    SizeMode = PictureBoxSizeMode.StretchImage

                };
                imgC.Click += new EventHandler(cmnd_Click);

                Label lblC = new Label
                {
                    AutoSize = false,
                    Location = new Point(24, 192),
                    Size = new Size(180, 56),
                    Font = new Font("Microsoft Sans Serif", 12),
                    Text = listaComunidades[i].Nome,
                    TextAlign = ContentAlignment.MiddleCenter
                };
                lblC.Click += new EventHandler(cmnd_Click);

                cmnd.Controls.Add(lblC);
                cmnd.Controls.Add(imgC);
            }
        }

        private void cmnd_Click(object sender, EventArgs e)
        {
            Control clickedControl = sender as Control;
            Panel pnlCmnd = clickedControl.Parent as Panel;

            if (pnlCmnd != null)
            {
                int idComunidade;
                // Tente converter o Name do painel para um inteiro
                if (int.TryParse(pnlCmnd.Name, out idComunidade))
                {
                    Form10 entrarComunidade = new Form10(listaUsuario, contU, listaPostagens, listaConversas, null, listaComunidades, idComunidade);
                    this.Close();
                    entrarComunidade.Show();
                }
                else
                {
                    MessageBox.Show("O ID da comunidade não está em um formato correto.");
                }
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Form3 feed = new Form3(listaUsuario, contU, listaPostagens, listaConversas, listaComunidades);
            feed.Show();
            this.Close();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            Form4 perfilUsuario = new Form4(listaUsuario, contU, contU, listaPostagens, listaConversas, listaComunidades);
            perfilUsuario.Show();
            this.Close();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Form7 amigos = new Form7(listaUsuario, contU, listaPostagens, listaConversas, listaComunidades);
            amigos.Show();
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (buttonClicado == false)
            {
                criarPanelNotificacao();
                buttonClicado = true;

                if (panelNotificacao.Visible == false)
                {
                    panelNotificacao.Visible = true;
                }
            }
            else if (buttonClicado == true)
            {
                panelNotificacao.Visible = false;
                buttonClicado = false;
            }
        }

        public void criarPanelNotificacao()
        {
            panelNotificacao.Location = new Point(95, 320);
            panelNotificacao.Size = new Size(265, 135);
            panelNotificacao.BackColor = Color.White;
            panelNotificacao.AutoScroll = true;
            panelNotificacao.BorderStyle = BorderStyle.FixedSingle;

            Controls.Add(panelNotificacao);
            panelNotificacao.BringToFront();

            if (listaUsuario[contU].listaAmigos != null)
            {
                int locPerf = 5, locButton = 45;

                locPerf += (100 * listaUsuario[contU].listaAmigos.Count);
                locButton += (100 * listaUsuario[contU].listaAmigos.Count);

                buttonClicado = true;

                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    locPerf -= 100;
                    locButton -= 100;
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        if (listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem != null)
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile(listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem.FileName);
                            panelNotificacao.Controls.Add(imgNtf);
                        }
                        else
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile("Resources\\74472.png");
                            panelNotificacao.Controls.Add(imgNtf);
                        }

                        Label txtNtf = new Label();

                        txtNtf.Location = new Point(50, locPerf);
                        txtNtf.Text = "" + listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Nome + " enviou uma solicitação de amizade.";
                        txtNtf.Font = new Font("Microsoft Sans Serif", 10);
                        txtNtf.Width = 200;
                        txtNtf.Height = 40;
                        panelNotificacao.Controls.Add(txtNtf);

                        buttonAceitar = new Button();
                        buttonAceitar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo; ;

                        buttonAceitar.Location = new Point(50, locButton);
                        buttonAceitar.Width = 60;
                        buttonAceitar.Height = 30;
                        buttonAceitar.Text = "Aceitar";
                        buttonAceitar.BackColor = Color.MediumPurple;
                        buttonAceitar.FlatStyle = FlatStyle.Popup;
                        buttonAceitar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonAceitar);
                        buttonAceitar.Click += new EventHandler(buttonAceitar_Click);

                        buttonRecusar = new Button();
                        buttonRecusar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo;

                        buttonRecusar.Location = new Point(120, locButton);
                        buttonRecusar.Width = 60;
                        buttonRecusar.Height = 30;
                        buttonRecusar.Text = "Recusar";
                        buttonRecusar.BackColor = Color.Gray;
                        buttonRecusar.FlatStyle = FlatStyle.Popup;
                        buttonRecusar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonRecusar);
                        buttonRecusar.Click += new EventHandler(buttonRecusar_Click);
                    }
                }
            }
        }

        private void buttonAceitar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {
                    listaUsuario[contU].listaAmigos[i].amizade = true;
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNotificacao.Visible = false;

                    break;
                }
            }

            if (listaUsuario[idAmigo].listaAmigos == null)
            {
                listaUsuario[idAmigo].listaAmigos = new List<Amigos>();
            }

            Amigos amigos = new Amigos
            {
                idAmigo = contU,
                solicitacaoRecebida = false,
                amizade = true,
            };

            listaUsuario[idAmigo].listaAmigos.Add(amigos);

            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNotificacao.Controls.Clear();
            ntfVermelho();
        }

        public void ntfVermelho()
        {
            if (listaUsuario[contU].listaAmigos != null)
            {
                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        pingouNotificacao.Visible = true;
                    }

                }
            }
        }

        private void buttonRecusar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNotificacao.Visible = false;
                    break;
                }
            }
            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNotificacao.Controls.Clear();
            ntfVermelho();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 postagemUsuario = new Form5(listaUsuario, contU, listaPostagens, this, listaConversas, listaComunidades);
            postagemUsuario.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 voltarLogin = new Form2(null, listaUsuario, listaPostagens, listaConversas, listaComunidades);
            voltarLogin.Show();
            this.Close();
        }

        private void salvarBtn_Click(object sender, EventArgs e)
        {
            if (boxNome.Text == "" || boxDescricao.Text == "" || imgComunidade.Image == null)
            {
                MessageBox.Show("A comunidade não pôde ser criada, imagem, nome ou descrição ausentes");
            }
            else
            {
                Comunidade comunidade = new Comunidade
                {
                    Nome = boxNome.Text,
                    Descricao = boxDescricao.Text,
                    Imagem = imgCmnd,
                    idCriador = contU,
                };

                comunidade.listaMembros.Add(new Membros { idMembro = contU });
                listaComunidades.Add(comunidade);

                pnlComunidade.Controls.Clear();
                exibirComunidade();
                boxNome.Text = "";
                boxDescricao.Text = "";
                imgComunidade.Image = Image.FromFile("Resources\\multidao-de-usuarios.png");
            }
        }

        private void imgComunidade_Click(object sender, EventArgs e)
        {
            imgComunidade.BackgroundImage = null;
            OpenFileDialog imgPerfil = new OpenFileDialog();
            selecionarImg();

            this.imgCmnd = imgPerfil;

            try
            {
                if (imgPerfil.ShowDialog() == DialogResult.OK)
                {
                    if (imgComunidade != null)
                    {
                        imgComunidade.SizeMode = PictureBoxSizeMode.StretchImage;
                        imgComunidade.Image = Image.FromFile(imgPerfil.FileName);
                    }
                    else
                    {
                        MessageBox.Show("Controle PictureBox não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar a imagem: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void selecionarImg()
        {
            imgCmnd.Multiselect = false;
            imgCmnd.Title = "Selecionar Imagem";
            imgCmnd.Filter = "Imagens (*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF)|*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF|" +
                          "Todos os arquivos (*.*)|*.*";
            imgCmnd.CheckFileExists = true;
            imgCmnd.CheckPathExists = true;
            imgCmnd.FilterIndex = 1;
        }
    }
}
