﻿using Form8;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using static ehoprojetinnepae.Comunidades;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;

namespace ehoprojetinnepae
{
    public partial class Form3 : Form
    {
        int contU, i;
        bool buttonClicado = false;

        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Conversas> listaConversa = new List<Conversas>();
        private List<Comunidades.Comunidade> listaComunidades = new List<Comunidades.Comunidade>();
        private List<Postagem> listaPostagem = new List<Postagem>();

        Form3 feed;

        Panel panelNotificacao = new Panel();
        Button buttonRecusar;
        Button buttonAceitar;
        public Form3(List<Usuario> listaUsuario, int contU, List<Postagem> listaPostagem, List<Conversas> listaConversa, List<Comunidades.Comunidade> listacomunidade)
        {
            feed = this;
            listaComunidades = listacomunidade;
            this.listaUsuario = listaUsuario;
            this.listaConversa = listaConversa;
            this.contU = contU;



            InitializeComponent();

            if (listaUsuario[contU].Imagem != null)
            {
                imagemPerfil.BackgroundImage = null;
                imagemPerfil.SizeMode = PictureBoxSizeMode.StretchImage;
                imagemPerfil.Image = Image.FromFile(listaUsuario[contU].Imagem.FileName);
            }

            if (listaPostagem != null)
            {
                this.listaPostagem = listaPostagem;
                criarPostagem();
            }
            int locY = 40;
            for (int i = 0; i < listaUsuario.Count; i++)
            {
                if (listaUsuario[contU] != listaUsuario[i])
                {
                    msgSolidao.Visible = false;
                    criarAmigos(locY, i);
                    locY += 70;
                }
            }

            ntfVermelho();
        }
        public void criarPostagem()
        {
            panelAdd.Visible = false;
            try
            {
                int locY = 0;
                locY += (483 * listaPostagem.Count);
                for (int i = 0; i < listaPostagem.Count; i++)
                {
                    locY -= 483;
                    Panel panel = new Panel
                    {
                        Location = new Point(0, locY),
                        Size = new Size(936, 481),
                    };
                    feedPanel.Controls.Add(panel);

                    // Carregar imagem do usuário
                    string caminhoImagemUsuario = listaUsuario[listaPostagem[i].contUP].Imagem?.FileName;
                    if (caminhoImagemUsuario != null && File.Exists(caminhoImagemUsuario))
                    {
                        PictureBox pictureBox = new PictureBox
                        {
                            Location = new Point(235, 10),
                            Size = new Size(45, 45),
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            BorderStyle = BorderStyle.FixedSingle,
                            Image = Image.FromFile(caminhoImagemUsuario)
                        };
                        panel.Controls.Add(pictureBox);
                    }
                    else
                    {
                        PictureBox pictureBox = new PictureBox
                        {
                            Location = new Point(235, 10),
                            Size = new Size(45, 45),
                            SizeMode = PictureBoxSizeMode.StretchImage,
                            BorderStyle = BorderStyle.FixedSingle,
                            Image = Image.FromFile("Resources\\74472.png")
                        };
                        panel.Controls.Add(pictureBox);
                    }

                    // Carregar imagem da postagem
                    string caminhoImagemPostagem = listaPostagem[i].ImagemPostagem.FileName;
                    PictureBox picturePost = new PictureBox
                    {
                        Location = new Point(235, 70),
                        Size = new Size(500, 300),
                        SizeMode = PictureBoxSizeMode.Zoom
                    };

                    if (File.Exists(caminhoImagemPostagem))
                    {
                        picturePost.Image = Image.FromFile(caminhoImagemPostagem);
                    }

                    panel.Controls.Add(picturePost);

                    // Adicionar o restante dos controles (labels, curtidas, etc.) aqui...
                    Label label = new Label
                    {
                        Location = new Point(285, 30),
                        Size = new Size(450, 45),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = listaUsuario[listaPostagem[i].contUP].Nome
                    };

                    panel.Controls.Add(label);

                    Label labelPost = new Label
                    {
                        Location = new Point(235, 380),
                        Size = new Size(500, 45),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = listaPostagem[i].Texto
                    };

                    panel.Controls.Add(labelPost);

                    bool curtida = false;

                    if (listaUsuario[contU].postagensUsuario != null)
                    {
                        for (int u = 0; u < listaUsuario[contU].postagensUsuario.Count; u++)
                        {
                            if (listaUsuario[contU].postagensUsuario[u].contPost == i) // Verifique se o índice está correto
                            {
                                curtida = listaUsuario[contU].postagensUsuario[u].postagemCurtiu;
                                break;
                            }
                        }
                    }

                    // Defina a imagem de curtida com base na verificação
                    PictureBox imgCurtida = new PictureBox
                    {
                        Name = "" + i,
                        Location = new Point(235, 430),
                        Size = new Size(40, 40),
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Image = curtida ? Image.FromFile("Resources\\like-preenchido.png") : Image.FromFile("Resources\\like.png"),
                    };
                    panel.Controls.Add(imgCurtida);
                    imgCurtida.Click += new EventHandler(imgCurtida_Click);

                    Label lblCurtida = new Label
                    {
                        Name = "lblCurtida" + i, // Nome único baseado no índice da postagem
                        Location = new Point(285, 444),
                        Size = new Size(50, 20),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = "" + listaPostagem[i].curtida
                    };

                    panel.Controls.Add(lblCurtida);

                    PictureBox pictureComentario = new PictureBox
                    {
                        Location = new Point(335, 430),
                        Size = new Size(40, 40),
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Image = Image.FromFile("Resources\\bate-papo.png"),
                    };
                    pictureComentario.Name = i.ToString(); // Certifique-se de que é uma string numérica

                    pictureComentario.Click += new EventHandler(imgComent_Click);
                    panel.Controls.Add(pictureComentario);

                    Label lblComent = new Label
                    {
                        Location = new Point(385, 444),
                        Size = new Size(50, 20),
                        Font = new Font("Microsoft Sans Serif", 12),
                        Text = "" + listaPostagem[i].numComentario
                    };

                    panel.Controls.Add(lblComent);

                    Panel linhaDesign = new Panel
                    {
                        Location = new Point(0, 480),
                        Size = new Size(936, 1),
                        BackColor = Color.Indigo
                    };

                    panel.Controls.Add(linhaDesign);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao exibir as postagens: " + ex.Message);
            }
        }

        public void limparFeed()
        {
            feedPanel.Controls.Clear();
            buscaBox.Visible = true;
            pictureBox4.Visible = true;
        }

        public void criarAmigos(int locY, int i)
        {
            if (listaUsuario[i].Imagem != null)
            {
                PictureBox imagemUser = new PictureBox();
                imagemUser.Name = "" + i;

                imagemUser.Location = new Point(4, locY);
                imagemUser.Size = new Size(55, 55);
                imagemUser.SizeMode = PictureBoxSizeMode.StretchImage;
                imagemUser.BorderStyle = BorderStyle.FixedSingle;
                imagemUser.Image = Image.FromFile(listaUsuario[i].Imagem.FileName);
                panelPessoas.Controls.Add(imagemUser);
                imagemUser.Click += new EventHandler(imagemUser_Click);
            }
            else
            {
                PictureBox imagemUser = new PictureBox();
                imagemUser.Name = "" + i;

                imagemUser.Location = new Point(4, locY);
                imagemUser.Width = 55;
                imagemUser.Height = 55;
                imagemUser.SizeMode = PictureBoxSizeMode.StretchImage;
                imagemUser.BorderStyle = BorderStyle.FixedSingle;
                imagemUser.Image = Image.FromFile("Resources\\74472.png");
                panelPessoas.Controls.Add(imagemUser);
                imagemUser.Click += new EventHandler(imagemUser_Click);
            }
            Label nomeLbl = new Label();

            nomeLbl.Name = "" + i;
            nomeLbl.Location = new Point(60, locY);
            nomeLbl.AutoSize = false;
            nomeLbl.Text = listaUsuario[i].Nome;
            nomeLbl.TextAlign = ContentAlignment.TopLeft;
            nomeLbl.Font = new Font("Microsoft Sans Serif", 12);
            nomeLbl.Width = 72;
            nomeLbl.Height = 55;
            panelPessoas.Controls.Add(nomeLbl);
            nomeLbl.Click += new EventHandler(imagemUser_Click);
        }

        public void mudarTelaPost()
        {
            Form5 postagemUsuario = new Form5(listaUsuario, contU, listaPostagem, feed, listaConversa, listaComunidades);
            postagemUsuario.Show();
        }

        private void postButton_Click(object sender, EventArgs e)
        {
            mudarTelaPost();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form4 perfilUsuario = new Form4(listaUsuario, contU, contU, listaPostagem, listaConversa, listaComunidades);
            perfilUsuario.Show();
            this.Close();
        }

        private void addMidImg_Click(object sender, EventArgs e)
        {
            mudarTelaPost();
        }

        private void imgCurtida_Click(object sender, EventArgs e)
        {
            PictureBox imgCurtida = (PictureBox)sender;
            int postIndex = int.Parse(imgCurtida.Name); // Obtenha o índice da postagem
            CurtirPostagem(postIndex, imgCurtida);
        }

        private void CurtirPostagem(int postIndex, PictureBox imgCurtida)
        {
            // Inicializa a lista de postagens do usuário se não existir
            if (listaUsuario[contU].postagensUsuario == null)
            {
                listaUsuario[contU].postagensUsuario = new List<PostagemUsuario>();
            }

            bool postagemCurtida = false;

            // Verifica se a postagem já foi curtida e se pertence à comunidade atual
            for (int u = 0; u < listaUsuario[contU].postagensUsuario.Count; u++)
            {
                if (listaUsuario[contU].postagensUsuario[u].contPost == postIndex) // Verifica se a postagem é da comunidade atual
                {
                    postagemCurtida = true;

                    if (listaUsuario[contU].postagensUsuario[u].postagemCurtiu)
                    {
                        // Descurtir
                        imgCurtida.Image = Image.FromFile("Resources\\like.png");
                        if (listaPostagem[postIndex].curtida > 0) // Verifica se a contagem de curtidas é maior que 0
                        {
                            listaPostagem[postIndex].curtida--;
                        }
                        listaUsuario[contU].postagensUsuario[u].postagemCurtiu = false;
                    }
                    else
                    {
                        // Curtir
                        imgCurtida.Image = Image.FromFile("Resources\\like-preenchido.png");
                        listaPostagem[postIndex].curtida++;
                        listaUsuario[contU].postagensUsuario[u].postagemCurtiu = true;
                    }
                    break;
                }
            }

            // Se a postagem não foi curtida, adiciona uma nova entrada
            if (!postagemCurtida)
            {
                PostagemUsuario postagemUsuario = new PostagemUsuario
                {
                    contPost = postIndex,
                    postagemCurtiu = true
                };
                listaUsuario[contU].postagensUsuario.Add(postagemUsuario);
                imgCurtida.Image = Image.FromFile("Resources\\like-preenchido.png");
                listaPostagem[postIndex].curtida++;

            }

            // Atualiza o número de likes no Label correspondente
            Label lblCurtida = (Label)feedPanel.Controls.Find("lblCurtida" + postIndex, true).FirstOrDefault();
            if (lblCurtida != null)
            {
                lblCurtida.Text = listaPostagem[postIndex].curtida.ToString(); // Atualiza o texto do Label
            }
        }

        private void imgComent_Click(object sender, EventArgs e)
        {
            PictureBox imgComent = (PictureBox)sender;
            Form6 abaComentarios = new Form6(listaUsuario, listaPostagem, contU, int.Parse(imgComent.Name), feed, null, listaConversa, listaComunidades, -1);

            abaComentarios.Show();
        }

        private void imagemUser_Click(object sender, EventArgs e)
        {
            Control clickedControl = sender as Control;
            Form4 perfilAmigo = new Form4(listaUsuario, contU, int.Parse(clickedControl.Name), listaPostagem, listaConversa, listaComunidades);

            perfilAmigo.Show();
            this.Close();
        }
        private void sairButton_Click(object sender, EventArgs e)
        {
            Form2 voltarLogin = new Form2(null, listaUsuario, listaPostagem, listaConversa, listaComunidades);
            voltarLogin.Show();
            this.Close();
        }

        private void buttonNotificacao_Click(object sender, EventArgs e)
        {
            if (buttonClicado == false)
            {
                criarPanelNotificacao();
                buttonClicado = true;

                if (panelNotificacao.Visible == false)
                {
                    panelNotificacao.Visible = true;
                }
            }
            else if (buttonClicado == true)
            {
                panelNotificacao.Visible = false;
                buttonClicado = false;
            }
        }

        public void criarPanelNotificacao()
        {
            panelNotificacao.Location = new Point(95, 320);
            panelNotificacao.Size = new Size(265, 135);
            panelNotificacao.BackColor = Color.White;
            panelNotificacao.AutoScroll = true;
            panelNotificacao.BorderStyle = BorderStyle.FixedSingle;

            feed.Controls.Add(panelNotificacao);
            panelNotificacao.BringToFront();

            if (listaUsuario[contU].listaAmigos != null)
            {
                int locPerf = 5, locButton = 45;

                locPerf += (100 * listaUsuario[contU].listaAmigos.Count);
                locButton += (100 * listaUsuario[contU].listaAmigos.Count);

                buttonClicado = true;

                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    locPerf -= 100;
                    locButton -= 100;
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        if (listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem != null)
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile(listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem.FileName);
                            panelNotificacao.Controls.Add(imgNtf);
                        }
                        else
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile("Resources\\74472.png");
                            panelNotificacao.Controls.Add(imgNtf);
                        }

                        Label txtNtf = new Label();

                        txtNtf.Location = new Point(50, locPerf);
                        txtNtf.Text = "" + listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Nome + " enviou uma solicitação de amizade.";
                        txtNtf.Font = new Font("Microsoft Sans Serif", 10);
                        txtNtf.Width = 200;
                        txtNtf.Height = 40;
                        panelNotificacao.Controls.Add(txtNtf);

                        buttonAceitar = new Button();
                        buttonAceitar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo; ;

                        buttonAceitar.Location = new Point(50, locButton);
                        buttonAceitar.Width = 60;
                        buttonAceitar.Height = 30;
                        buttonAceitar.Text = "Aceitar";
                        buttonAceitar.BackColor = Color.MediumPurple;
                        buttonAceitar.FlatStyle = FlatStyle.Popup;
                        buttonAceitar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonAceitar);
                        buttonAceitar.Click += new EventHandler(buttonAceitar_Click);

                        buttonRecusar = new Button();
                        buttonRecusar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo;

                        buttonRecusar.Location = new Point(120, locButton);
                        buttonRecusar.Width = 60;
                        buttonRecusar.Height = 30;
                        buttonRecusar.Text = "Recusar";
                        buttonRecusar.BackColor = Color.Gray;
                        buttonRecusar.FlatStyle = FlatStyle.Popup;
                        buttonRecusar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonRecusar);
                        buttonRecusar.Click += new EventHandler(buttonRecusar_Click);
                    }
                }
            }
        }

        private void buttonAceitar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {   
                    listaUsuario[contU].listaAmigos[i].amizade = true; 
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNotificacao.Visible = false;

                    break;
                }
            }

            if (listaUsuario[idAmigo].listaAmigos == null)
            {
                listaUsuario[idAmigo].listaAmigos = new List<Amigos>();
            }

            Amigos amigos = new Amigos
            {
                idAmigo = contU,
                solicitacaoRecebida = false,
                amizade = true,
            };

            listaUsuario[idAmigo].listaAmigos.Add(amigos);

            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNotificacao.Controls.Clear();
            ntfVermelho();
        }

        public void ntfVermelho()
        {
            if (listaUsuario[contU].listaAmigos != null)
            {
                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        pingouNotificacao.Visible = true;
                    }

                }
            }
        }

        private void buttonRecusar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNotificacao.Visible = false;
                    break;
                }
            }
            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNotificacao.Controls.Clear();
            ntfVermelho();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Comunidades comunidades = new Comunidades(listaUsuario, contU, listaPostagem, listaConversa, listaComunidades);
            comunidades.Show();
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            
        }

        private void jogarButton_Click(object sender, EventArgs e)
        {
            Form9 jogar = new Form9(listaUsuario, contU, listaPostagem, listaConversa, listaComunidades);
            jogar.Show();
            this.Close();
        }

        private void pictureBox4_Click_1(object sender, EventArgs e)
        {
            // Verifica se o painel de busca já existe
            FlowLayoutPanel panelBusca = Controls.OfType<FlowLayoutPanel>().FirstOrDefault(p => p.Name == "panelBusca");

            if (panelBusca == null) // Se não existe, cria o painel
            {
                panelBusca = new FlowLayoutPanel
                {
                    Name = "panelBusca", // Nome para identificação
                    Location = new Point(328, 40),
                    Size = new Size(500, 75),
                    BorderStyle = BorderStyle.FixedSingle,
                    AutoScroll = true,
                    BackColor = Color.White
                };
                Controls.Add(panelBusca);
            }

            // Alterna a visibilidade do painel de busca
            panelBusca.Visible = !panelBusca.Visible;

            // Se o painel estiver visível, preenche-o com os usuários que correspondem à busca
            if (panelBusca.Visible)
            {
                panelBusca.Controls.Clear(); // Limpa o painel antes de adicionar novos controles

                if (listaUsuario != null)
                {
                    for (int i = 0; i < listaUsuario.Count; i++)
                    {
                        if (listaUsuario[i].Nome.ToLower().Contains(buscaBox.Text.ToLower()))
                        {
                            Panel panelPessoa = new Panel()
                            {
                                Location = new Point(3, 0),
                                Size = new Size(475, 45)
                            };
                            panelBusca.Controls.Add(panelPessoa);

                            PictureBox imgPessoa = new PictureBox()
                            {
                                Location = new Point(3, 3),
                                Size = new Size(40, 40),
                                BorderStyle = BorderStyle.FixedSingle,
                                Image = listaUsuario[i].Imagem != null ? Image.FromFile(listaUsuario[i].Imagem.FileName) : Image.FromFile("Resources\\74472.png"),
                                SizeMode = PictureBoxSizeMode.StretchImage,
                                Name = "" + i
                            };
                            panelPessoa.Controls.Add(imgPessoa);
                            imgPessoa.Click += new EventHandler(imagemUser_Click);

                            Label nomePessoa = new Label()
                            {
                                AutoSize = false,
                                Location = new Point(50, 3),
                                Size = new Size(420, 40),
                                Text = listaUsuario[i].Nome,
                                Font = new Font("Microsoft Sans Serif", 10),
                                Name = "" + i
                            };
                            panelPessoa.Controls.Add(nomePessoa);
                            nomePessoa.Click += new EventHandler(imagemUser_Click);
                        }
                    }
                }

                // Certifique-se de que o painel de busca está na frente
                panelBusca.BringToFront();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form7 amigos = new Form7(listaUsuario, contU, listaPostagem, listaConversa, listaComunidades);
            amigos.Show();
            this.Close();
        }
    }
}