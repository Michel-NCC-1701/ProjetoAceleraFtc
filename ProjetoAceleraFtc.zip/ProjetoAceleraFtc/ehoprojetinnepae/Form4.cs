﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static ehoprojetinnepae.Comunidades;
using static ehoprojetinnepae.Form1;
using static ehoprojetinnepae.Form5;
using static ehoprojetinnepae.Form7;
using Label = System.Windows.Forms.Label;

namespace ehoprojetinnepae
{
    public partial class Form4 : Form
    {
        private List<Usuario> listaUsuario = new List<Usuario>();
        private List<Postagem> listaPostagem = new List<Postagem>();
        private List<Conversas> listaConversa = new List<Conversas>();
        private List<Comunidade> listaComunidade = new List<Comunidade>();

        int contU, contA;
        bool menu = false, buttonClicado = false;

        private OpenFileDialog ofd1 = new OpenFileDialog();

        Panel linhaLateral = new Panel();
        Panel panelNotificacao = new Panel();
        PictureBox pingouNtf = new PictureBox();

        Button buttonSolicitacion = new Button();
        Button buttonSair = new Button();
        Button buttonAdd = new Button();
        Button buttonRecusar;
        Button buttonAceitar;

        PictureBox homeImg = new PictureBox();
        PictureBox buttonAmg = new PictureBox();
        PictureBox buttonCmnd = new PictureBox();
        PictureBox buttonNtf = new PictureBox();

        Form4 perfil;

        public Form4(List<Usuario> listaUsuario, int contU, int contA, List<Postagem> listaPostagem, List<Conversas> listaConversa, List<Comunidade> listaComunidades)
        {
            perfil = this;
            listaComunidade = listaComunidades;
            this.listaConversa = listaConversa;
            this.listaUsuario = listaUsuario;
            this.contU = contU;
            this.contA = contA;

            if (listaPostagem != null)
            {
                this.listaPostagem = listaPostagem;
            }

            InitializeComponent();

            if (contU != contA)
            {
                criarButton();
            }

            AtualizarBotaoSolicitacao();

            if (listaUsuario[contA].Imagem != null)
            {
                imagemPerfil.BackgroundImage = null;
                imagemPerfil.SizeMode = PictureBoxSizeMode.StretchImage;
                imagemPerfil.Image = Image.FromFile(listaUsuario[contA].Imagem.FileName);
            }

            if (listaPostagem != null)
            {
                int contPostU = 0;
                for (int i = 0; i < listaPostagem.Count; i++)
                {
                    if (listaPostagem[i].contUP == contA)
                    {
                        contPostU++;
                    }
                }

                for (int i = 0; i < listaPostagem.Count; i++) 
                {
                    if (listaPostagem[i].contUP == contA)
                    {
                        criarPostagem(i);
                    }
                }
            }

            label1.Text = listaUsuario[contA].Nome;
            buttonSair.Click += new EventHandler(buttonSair_Click);
            buttonAdd.Click += new EventHandler(buttonAdd_Click);
            homeImg.Click += new EventHandler(homeImg_Click);
            buttonSolicitacion.Click += new EventHandler(buttonSolicitacion_Click);
            buttonAmg.Click += new EventHandler(buttonAmg_Click);
            buttonCmnd.Click += new EventHandler(buttonCmnd_Click);
        }

        private void buttonCmnd_Click(object sender, EventArgs e)
        {
            Comunidades comunidades = new Comunidades(listaUsuario, contU, listaPostagem, listaConversa, listaComunidade);
            comunidades.Show();
            this.Close();
        }

        public void criarPostagem(int i)
        {
            Panel panelPost = new Panel
            {
                Margin = new Padding(1),
                Size = new Size(415, 265),
                BackColor = Color.White,
            };
            flowLayoutPanel1.Controls.Add(panelPost);
            if (!string.IsNullOrEmpty(listaPostagem[i].ImagemPostagem.FileName))
            {
                PictureBox postImg = new PictureBox();

                postImg.Location = new Point(11, 7);
                postImg.Size = new Size(390, 195);
                postImg.SizeMode = PictureBoxSizeMode.Zoom;
                postImg.Image = Image.FromFile(listaPostagem[i].ImagemPostagem.FileName);
                panelPost.Controls.Add(postImg);

                Label postTxt = new Label();

                postTxt.Location = new Point(14, 204);
                postTxt.AutoSize = false;
                postTxt.Text = listaPostagem[i].Texto;
                postTxt.TextAlign = ContentAlignment.TopLeft;
                postTxt.Font = new Font("Microsoft Sans Serif", 12);
                postTxt.Size = new Size(387, 54);
                panelPost.Controls.Add(postTxt);
            }
            else
            {
                Label postTxt = new Label();

                postTxt.Location = new Point(14, 204);
                postTxt.AutoSize = false;
                postTxt.Text = listaPostagem[i].Texto;
                postTxt.TextAlign = ContentAlignment.TopLeft;
                postTxt.Font = new Font("Microsoft Sans Serif", 12);
                postTxt.Size = new Size(387, 54);
                flowLayoutPanel1.Controls.Add(postTxt);
            }
        }
                
        private void imagemPerfil_Click(object sender, System.EventArgs e)
        {
            if (contU == contA)
            {
                imagemPerfil.BackgroundImage = null;
                OpenFileDialog imgPerfil = new OpenFileDialog();
                selecionarImg();

                try
                {
                    if (imgPerfil.ShowDialog() == DialogResult.OK)
                    {
                        if (imagemPerfil != null)
                        {
                            imagemPerfil.SizeMode = PictureBoxSizeMode.StretchImage;
                            imagemPerfil.Image = Image.FromFile(imgPerfil.FileName);
                            listaUsuario[contU].Imagem = imgPerfil;
                        }
                        else
                        {
                            MessageBox.Show("Controle PictureBox não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar a imagem: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void selecionarImg()
        {
            ofd1.Multiselect = false;
            ofd1.Title = "Selecionar Imagem";
            ofd1.Filter = "Imagens (*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF)|*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF|" +
                          "Todos os arquivos (*.*)|*.*";
            ofd1.CheckFileExists = true;
            ofd1.CheckPathExists = true;
            ofd1.FilterIndex = 1;
        }

        public void criarPanel()
        {
            Panel linhaDesign = new Panel();

            Label logo = new Label
            {
                Location = new Point(25, 140),
                Text = "Inicio",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label perfil = new Label
            {
                Location = new Point(25, 220),
                Text = "Perfil",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label amigos = new Label
            {
                Location = new Point(19, 300),
                Text = "Amigos",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label Comunidade = new Label
            {
                Location = new Point(-2, 380),
                Text = "Comunidades",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label notificacao = new Label
            {
                Location = new Point(9, 460),
                Text = "Notificação",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label postarMais = new Label
            {
                Location = new Point(23, 540),
                Text = "Postar",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            Label sair = new Label
            {
                Location = new Point(28, 660),
                Text = "Sair",
                Font = new Font("Microsoft Sans Serif", 12)
            };

            PictureBox perfilImg = new PictureBox();   

            linhaLateral.Location = new Point(0 , 0);
            linhaLateral.Size = new Size(110, 684);
            linhaLateral.BackColor = Color.White;
                        
            linhaDesign.Location = new Point(100, 0);
            linhaDesign.Size = new Size(10, 684);
            linhaDesign.BackColor = Color.FromArgb(70, 0, 70);
                        
            homeImg.Location = new Point(25, 90);
            homeImg.Size = new Size(50, 50);
            homeImg.SizeMode = PictureBoxSizeMode.Zoom;
            homeImg.BorderStyle = BorderStyle.FixedSingle;
            homeImg.Image = Image.FromFile("Resources\\logoImg.png");

            if (listaUsuario[contU].Imagem == null)
            {
                perfilImg.Location = new Point(25, 170);
                perfilImg.Size = new Size(50, 50);
                perfilImg.BorderStyle = BorderStyle.FixedSingle;
                perfilImg.SizeMode = PictureBoxSizeMode.StretchImage;
                perfilImg.Image = Image.FromFile("Resources\\74472.png");
            }
            else
            {
                perfilImg.Location = new Point(25, 170);
                perfilImg.Size = new Size(50, 50);
                perfilImg.BackgroundImage = null;
                perfilImg.BorderStyle = BorderStyle.FixedSingle;
                perfilImg.SizeMode = PictureBoxSizeMode.StretchImage;
                perfilImg.Image = Image.FromFile(listaUsuario[contU].Imagem.FileName);
            }
            perfilImg.Click += new EventHandler(perfilImg_Click);

            buttonAmg.Location = new Point(25, 250);
            buttonAmg.Size = new Size(50, 50);
            buttonAmg.SizeMode = PictureBoxSizeMode.Zoom;
            buttonAmg.BorderStyle = BorderStyle.FixedSingle;
            buttonAmg.Image = Image.FromFile("Resources\\amigos.png");

            buttonCmnd.Location = new Point(25, 330);
            buttonCmnd.Size = new Size(50, 50);
            buttonCmnd.SizeMode = PictureBoxSizeMode.Zoom;
            buttonCmnd.BorderStyle = BorderStyle.FixedSingle;
            buttonCmnd.Image = Image.FromFile("Resources\\multidao-de-usuarios.png");

            buttonNtf.Location = new Point(25, 410);
            buttonNtf.Size = new Size(50, 50);
            buttonNtf.SizeMode = PictureBoxSizeMode.Zoom;
            buttonNtf.BorderStyle = BorderStyle.FixedSingle;
            buttonNtf.Image = Image.FromFile("Resources\\notificacao.png");
            buttonNtf.Click += new EventHandler(butotnNtf_Click);

            pingouNtf.Location = new Point(57, 415);
            pingouNtf.Size = new Size(15, 15);
            pingouNtf.BorderStyle = BorderStyle.FixedSingle;
            pingouNtf.BackColor = Color.Red;
            Controls.Add(pingouNtf);
            pingouNtf.BringToFront(); 

            buttonAdd.Location = new Point(25, 490);
            buttonAdd.Size = new Size(50, 50);
            buttonAdd.BackColor = Color.White;
            buttonAdd.Text = "+";
            buttonAdd.TextAlign = ContentAlignment.MiddleCenter;
            buttonAdd.ImageAlign = ContentAlignment.MiddleCenter;
            buttonAdd.Font = new Font("Microsoft Sans Serif", 16);

            buttonSair.Location = new Point(25, 610);
            buttonSair.Size = new Size(50, 50);
            buttonSair.BackColor = Color.White;
            buttonSair.Text = "X";
            buttonSair.TextAlign = ContentAlignment.MiddleCenter;
            buttonSair.ImageAlign = ContentAlignment.MiddleCenter;
            buttonSair.Font = new Font("Microsoft Sans Serif", 16);

            this.Controls.Add(linhaLateral);
            linhaLateral.Controls.Add(linhaDesign);
            linhaLateral.Controls.Add(homeImg);
            linhaLateral.Controls.Add(perfilImg);
            linhaLateral.Controls.Add(buttonAmg);
            linhaLateral.Controls.Add(buttonCmnd);
            linhaLateral.Controls.Add(buttonNtf);
            linhaLateral.Controls.Add(pingouNtf);
            linhaLateral.Controls.Add(buttonAdd);
            linhaLateral.Controls.Add(buttonSair);
            linhaLateral.Controls.Add(logo);
            linhaLateral.Controls.Add(amigos);
            linhaLateral.Controls.Add(Comunidade);
            linhaLateral.Controls.Add(notificacao);
            linhaLateral.Controls.Add(postarMais);
            linhaLateral.Controls.Add(perfil);
            linhaLateral.Controls.Add(sair);
            linhaLateral.BringToFront();
        }

        private void perfilImg_Click(object sender, EventArgs e)
        {
            Form4 perfilUsuario = new Form4(listaUsuario, contU, contU, listaPostagem, listaConversa, listaComunidade);
            perfilUsuario.Show();
            this.Close();
        }

        private void butotnNtf_Click(object sender, EventArgs e)
        {
            if (buttonClicado == false)
            {
                criarPanelNotificacao();
                buttonClicado = true;

                if (panelNotificacao.Visible == false)
                {
                    panelNotificacao.Visible = true;
                }
            }
            else if (buttonClicado == true)
            {
                panelNotificacao.Visible = false;
                buttonClicado = false;
            }
        }

        public void criarPanelNotificacao()
        {
            panelNotificacao.Location = new Point(95, 320);
            panelNotificacao.Size = new Size(265, 135);
            panelNotificacao.BackColor = Color.White;
            panelNotificacao.AutoScroll = true;
            panelNotificacao.BorderStyle = BorderStyle.FixedSingle;

            linhaLateral.Controls.Add(panelNotificacao);
            panelNotificacao.BringToFront();

            if (listaUsuario[contU].listaAmigos != null)
            {
                int locPerf = 5, locButton = 45;

                locPerf += (100 * listaUsuario[contU].listaAmigos.Count);
                locButton += (100 * listaUsuario[contU].listaAmigos.Count);

                buttonClicado = true;

                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    locPerf -= 100;
                    locButton -= 100;
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        if (listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem != null)
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile(listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Imagem.FileName);
                            panelNotificacao.Controls.Add(imgNtf);
                        }
                        else
                        {
                            PictureBox imgNtf = new PictureBox();

                            imgNtf.Location = new Point(5, locPerf);
                            imgNtf.Width = 40;
                            imgNtf.Height = 40;
                            imgNtf.SizeMode = PictureBoxSizeMode.StretchImage;
                            imgNtf.BorderStyle = BorderStyle.FixedSingle;
                            imgNtf.Image = Image.FromFile("Resources\\74472.png");
                            panelNotificacao.Controls.Add(imgNtf);
                        }

                        Label txtNtf = new Label();

                        txtNtf.Location = new Point(50, locPerf);
                        txtNtf.Text = "" + listaUsuario[listaUsuario[contU].listaAmigos[i].idAmigo].Nome + " enviou uma solicitação de amizade.";
                        txtNtf.Font = new Font("Microsoft Sans Serif", 10);
                        txtNtf.Width = 200;
                        txtNtf.Height = 40;
                        panelNotificacao.Controls.Add(txtNtf);

                        buttonAceitar = new Button();
                        buttonAceitar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo; ;

                        buttonAceitar.Location = new Point(50, locButton);
                        buttonAceitar.Width = 60;
                        buttonAceitar.Height = 30;
                        buttonAceitar.Text = "Aceitar";
                        buttonAceitar.BackColor = Color.CornflowerBlue;
                        buttonAceitar.FlatStyle = FlatStyle.Popup;
                        buttonAceitar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonAceitar);
                        buttonAceitar.Click += new EventHandler(buttonAceitar_Click);

                        buttonRecusar = new Button();
                        buttonRecusar.Name = "" + listaUsuario[contU].listaAmigos[i].idAmigo;

                        buttonRecusar.Location = new Point(120, locButton);
                        buttonRecusar.Width = 60;
                        buttonRecusar.Height = 30;
                        buttonRecusar.Text = "Recusar";
                        buttonRecusar.BackColor = Color.Gray;
                        buttonRecusar.FlatStyle = FlatStyle.Popup;
                        buttonRecusar.TextAlign = ContentAlignment.MiddleCenter;
                        panelNotificacao.Controls.Add(buttonRecusar);
                        buttonRecusar.Click += new EventHandler(buttonRecusar_Click);
                    }
                }
            }
        }

        private void buttonAceitar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {
                    listaUsuario[contU].listaAmigos[i].amizade = true;
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNtf.Visible = false;

                    break;
                }
            }

            if (listaUsuario[idAmigo].listaAmigos == null)
            {
                listaUsuario[idAmigo].listaAmigos = new List<Amigos>();
            }

            Amigos amigos = new Amigos
            {
                idAmigo = contU,
                solicitacaoRecebida = false,
                amizade = true,
            };

            listaUsuario[idAmigo].listaAmigos.Add(amigos);

            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNtf.Controls.Clear();
            ntfVermelho();
        }

        public void ntfVermelho()
        {
            if (listaUsuario[contU].listaAmigos != null)
            {
                for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
                {
                    if (listaUsuario[contU].listaAmigos[i].solicitacaoRecebida == true)
                    {
                        pingouNtf.Visible = true;
                    }

                }
            }
        }

        private void buttonRecusar_Click(object sender, EventArgs e)
        {
            int idAmigo = int.Parse(((Button)sender).Name);

            for (int i = 0; i < listaUsuario[contU].listaAmigos.Count; i++)
            {
                if (listaUsuario[contU].listaAmigos[i].idAmigo == idAmigo)
                {
                    listaUsuario[contU].listaAmigos[i].solicitacaoRecebida = false;
                    pingouNtf.Visible = false;
                    break;
                }
            }
            panelNotificacao.Controls.Clear();
            criarPanelNotificacao();

            pingouNtf.Controls.Clear();
            ntfVermelho();
        }

        public void criarButton()
        {
            buttonSolicitacion.Location = new Point(83, 168);
            buttonSolicitacion.Size = new Size(150, 46);    
            buttonSolicitacion.BackColor = Color.MediumPurple;
            buttonSolicitacion.FlatStyle = FlatStyle.Popup;
            buttonSolicitacion.Text = "Solicitar Amizade";
            buttonSolicitacion.TextAlign = ContentAlignment.MiddleCenter;
            buttonSolicitacion.ImageAlign = ContentAlignment.MiddleCenter;
            buttonSolicitacion.Font = new Font("Microsoft Sans Serif", 8);


            perfilPosts.Controls.Add(buttonSolicitacion);
        }

        public void AtualizarBotaoSolicitacao()
        {
            if (listaUsuario[contA].listaAmigos != null)
            {
                for (int i = 0; i < listaUsuario[contA].listaAmigos.Count; i++)
                {
                    if (listaUsuario[contA].listaAmigos[i].idAmigo == contU)
                    {
                        if (listaUsuario[contA].listaAmigos[i].amizade)
                        {
                            buttonSolicitacion.BackColor = Color.Transparent;
                            buttonSolicitacion.Text = "Amigos";
                            buttonSolicitacion.Enabled = false;
                        }
                        else if (listaUsuario[contA].listaAmigos[i].solicitacaoRecebida)
                        {
                            buttonSolicitacion.BackColor = Color.Gray;
                            buttonSolicitacion.Text = "Cancelar Solicitação";
                            buttonClicado = true;
                        }
                        else
                        {
                            buttonSolicitacion.BackColor = Color.MediumPurple;
                            buttonSolicitacion.Text = "Solicitar Amizade";
                            buttonClicado = false;
                        }
                        return;
                    }
                }
            }
        }

        private void buttonSolicitacion_Click(object sender, EventArgs e)
        {
            if (buttonClicado == true)
            {
                botaoCinza();
            }
            else
            {
                botaoAzul();
            }
        }

        private void buttonAmg_Click(object sender, EventArgs e)
        {
            Form7 amigos = new Form7(listaUsuario, contU, listaPostagem, listaConversa, listaComunidade);
            amigos.Show();
            this.Close();
        }

        public void botaoCinza()
        {
            if (listaUsuario[contA].listaAmigos != null)
            {
                listaUsuario[contA].listaAmigos = new List<Amigos>();

                for (int i = 0; i < listaUsuario[contA].listaAmigos.Count; i++)
                {
                    if (listaUsuario[contA].listaAmigos[i].idAmigo == contU)
                    {
                        listaUsuario[contA].listaAmigos[i] = null;
                        listaUsuario[contA].listaAmigos[i] = null;
                    }
                }
            }

            buttonSolicitacion.BackColor = Color.CornflowerBlue;
            buttonSolicitacion.Text = "Solicitar Amizade";

            buttonClicado = false;
        }

        public void botaoAzul()
        {
            if (listaUsuario[contA].listaAmigos == null)
            {
                listaUsuario[contA].listaAmigos = new List<Amigos>();
            }

            Amigos amigos = new Amigos
            {
                idAmigo = contU,
                solicitacaoRecebida = true,
            };

            listaUsuario[contA].listaAmigos.Add(amigos);

            buttonSolicitacion.BackColor = Color.Gray;
            buttonSolicitacion.Text = "Cancelar Solicitação";

            buttonClicado = true;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            abrirPostar();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            Form2 login = new Form2(null, listaUsuario, listaPostagem, listaConversa, listaComunidade);
            login.Show();
            this.Close();
        }

        public void abrirPostar()
        {
            Form5 postagemUsuario = new Form5(listaUsuario, contU, listaPostagem, perfil, listaConversa, listaComunidade);
            postagemUsuario.Show();
        }

        private void homeImg_Click(object sender, EventArgs e)
        {
            Form3 feed = new Form3(listaUsuario, contU, listaPostagem, listaConversa, listaComunidade);
            feed.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (menu == false)
            {
                criarPanel();
                ntfVermelho();
                menu = true;
                button1.BringToFront();

                if (linhaLateral.Visible == false)
                {
                    linhaLateral.Visible = true;
                }
            } 
            else if (menu == true)
            {
                linhaLateral.Visible = false;
                menu = false;
            }                        
        }

        private void addMidImg_Click(object sender, EventArgs e)
        {
            abrirPostar();
        }
    }
}