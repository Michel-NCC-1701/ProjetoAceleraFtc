﻿namespace Form8
{
    internal class Comunidade
    {
    }
}