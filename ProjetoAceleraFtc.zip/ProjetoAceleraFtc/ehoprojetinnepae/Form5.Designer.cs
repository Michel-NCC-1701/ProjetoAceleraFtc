﻿namespace ehoprojetinnepae
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.postNameLabel = new System.Windows.Forms.Label();
            this.postBox = new System.Windows.Forms.TextBox();
            this.setaButton = new System.Windows.Forms.Button();
            this.inserirImagem = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.imagemPreview = new System.Windows.Forms.PictureBox();
            this.cmndBtn = new System.Windows.Forms.CheckBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.comunidadeBox = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.inserirImagem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagemPreview)).BeginInit();
            this.SuspendLayout();
            // 
            // postNameLabel
            // 
            this.postNameLabel.AutoSize = true;
            this.postNameLabel.Location = new System.Drawing.Point(85, 23);
            this.postNameLabel.Name = "postNameLabel";
            this.postNameLabel.Size = new System.Drawing.Size(25, 13);
            this.postNameLabel.TabIndex = 1;
            this.postNameLabel.Text = "122";
            // 
            // postBox
            // 
            this.postBox.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.postBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postBox.Location = new System.Drawing.Point(88, 37);
            this.postBox.Multiline = true;
            this.postBox.Name = "postBox";
            this.postBox.Size = new System.Drawing.Size(243, 91);
            this.postBox.TabIndex = 2;
            // 
            // setaButton
            // 
            this.setaButton.BackColor = System.Drawing.Color.Transparent;
            this.setaButton.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.next;
            this.setaButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.setaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setaButton.Location = new System.Drawing.Point(336, 107);
            this.setaButton.Name = "setaButton";
            this.setaButton.Size = new System.Drawing.Size(30, 30);
            this.setaButton.TabIndex = 3;
            this.setaButton.UseVisualStyleBackColor = false;
            this.setaButton.Click += new System.EventHandler(this.setaButton_Click);
            // 
            // inserirImagem
            // 
            this.inserirImagem.BackgroundImage = global::ehoprojetinnepae.Properties.Resources.galeria_de_fotos;
            this.inserirImagem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.inserirImagem.Location = new System.Drawing.Point(85, 131);
            this.inserirImagem.Name = "inserirImagem";
            this.inserirImagem.Size = new System.Drawing.Size(20, 20);
            this.inserirImagem.TabIndex = 4;
            this.inserirImagem.TabStop = false;
            this.inserirImagem.Click += new System.EventHandler(this.inserirImagem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ehoprojetinnepae.Properties.Resources._74472;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(39, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // imagemPreview
            // 
            this.imagemPreview.Location = new System.Drawing.Point(57, 215);
            this.imagemPreview.Name = "imagemPreview";
            this.imagemPreview.Size = new System.Drawing.Size(300, 200);
            this.imagemPreview.TabIndex = 5;
            this.imagemPreview.TabStop = false;
            // 
            // cmndBtn
            // 
            this.cmndBtn.AutoSize = true;
            this.cmndBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmndBtn.Location = new System.Drawing.Point(170, 131);
            this.cmndBtn.Name = "cmndBtn";
            this.cmndBtn.Size = new System.Drawing.Size(161, 20);
            this.cmndBtn.TabIndex = 6;
            this.cmndBtn.Text = "Postar na comunidade";
            this.cmndBtn.UseVisualStyleBackColor = true;
            this.cmndBtn.CheckedChanged += new System.EventHandler(this.cmndBtn_CheckedChanged);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(138, 157);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(193, 29);
            this.flowLayoutPanel1.TabIndex = 7;
            // 
            // comunidadeBox
            // 
            this.comunidadeBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comunidadeBox.Location = new System.Drawing.Point(138, 12);
            this.comunidadeBox.Name = "comunidadeBox";
            this.comunidadeBox.Size = new System.Drawing.Size(193, 23);
            this.comunidadeBox.TabIndex = 8;
            this.comunidadeBox.Text = "label1";
            this.comunidadeBox.Visible = false;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(406, 446);
            this.Controls.Add(this.comunidadeBox);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.cmndBtn);
            this.Controls.Add(this.imagemPreview);
            this.Controls.Add(this.inserirImagem);
            this.Controls.Add(this.setaButton);
            this.Controls.Add(this.postBox);
            this.Controls.Add(this.postNameLabel);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Postagem";
            ((System.ComponentModel.ISupportInitialize)(this.inserirImagem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagemPreview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label postNameLabel;
        private System.Windows.Forms.TextBox postBox;
        private System.Windows.Forms.Button setaButton;
        private System.Windows.Forms.PictureBox inserirImagem;
        private System.Windows.Forms.PictureBox imagemPreview;
        private System.Windows.Forms.CheckBox cmndBtn;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label comunidadeBox;
    }
}